(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Vertical = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.2,1,1).p("EgWpgqKMAtTAAAMAAABUVMgtTAAAg");
	this.shape.setTransform(43.86,81.6491,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,89.8,165.3);


(lib.Símbolo1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AhZA3IAAhtICzAAIAABtg");
	this.shape.setTransform(9,1.8226,1,0.3306,0,180,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18,3.7);


(lib.PGrande = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B2B2A").s().p("A0+LwIAA3fMAp9AAAIAAXfg");
	this.shape.setTransform(12.1405,6.8149,0.0904,0.0904);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,24.3,13.6);


(lib.Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EhDLgODMCGXAAAIAAcHMiGXAAAg");
	this.shape.setTransform(130.0675,27.2142,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,262.2,56.5);


(lib.Carga4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape.setTransform(0.5,2.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1,4.1);


(lib.Carga3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgZAjIAAhFIAzAAIggBFg");
	this.shape.setTransform(2.6,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.9);


(lib.Carga2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgmAjIAhhFIAsAAIgiBFg");
	this.shape.setTransform(4.25,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.4,0,7.799999999999999,6.9);


(lib.Carga1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgbAjIAhhFIAWAAIAABFg");
	this.shape.setTransform(3.15,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.4,0,5.6,6.9);


(lib.Camara_Fondo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#3C3C3C").ss(1,1,1,3,true).p("AHyAAQAADOiRCTQiTCRjOAAQjOAAiSiRQiSiTAAjOQAAjOCSiSQCSiSDOAAQDOAACTCSQCRCSAADOg");
	this.shape.setTransform(655.35,382.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AlfFgQiTiSABjOQgBjOCTiRQCRiSDOAAQDPAACRCSQCTCRAADOQAADOiTCSQiRCSjPAAQjOAAiRiSg");
	this.shape_1.setTransform(655.35,382.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_2.setTransform(689.5,454.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_3.setTransform(620.2,455.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_4.setTransform(689.55,306.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_5.setTransform(620.25,306.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_6.setTransform(678.8,235.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_7.setTransform(640.7,235.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_8.setTransform(320.35,234.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_9.setTransform(285.25,235.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#121212").s().p("AlLDgIAAnAIKXAAIAAHAg");
	this.shape_10.setTransform(418,223.65);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#212121").s().p("Am7E0QhFAAAAhFIAAndQAAhFBFAAIN3AAQBFAAAABFIAAHdQAABFhFAAg");
	this.shape_11.setTransform(418.625,222.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AoTGfQi6AAAAi5IAAnLQAAi5C6AAIQnAAQC6AAAAC5IAAHLQAAC5i6AAg");
	this.shape_12.setTransform(417.55,217.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#454545").s().p("ArISZMAAAgkxIWRAAMAAAAkxg");
	this.shape_13.setTransform(653.8,379.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2B2B2A").s().p("A0+LwIAA3fMAp9AAAIAAXfg");
	this.shape_14.setTransform(406.8,383.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#212121").s().p("A2lOHIAA8NMAtLAAAIAAcNg");
	this.shape_15.setTransform(406.3,384.35);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#333333").s().p("A7ESeMAAAgk7MA2KAAAMAAAAk7g");
	this.shape_16.setTransform(410.7236,381.1892,0.9943,0.9834);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3C3C3C").s().p("EgjgAWNQifAAAAieMAAAgndQAAieCfAAMBHBAAAQCfAAAACeMAAAAndQAACeifAAg");
	this.shape_17.setTransform(481.5,355.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E7E7E7").s().p("EhLNAhOMAAAhCbMCWbAAAMAAABCbg");
	this.shape_18.setTransform(481.45,212.625);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#4A3829").s().p("EhK/ARHMAAAgiNMCV/AAAMAAAAiNg");
	this.shape_19.setTransform(479.975,531.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,962.9,641.3);


(lib.Boton_Sig = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiPhsIEfBvIkfBqg");
	this.shape.setTransform(14.375,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiPhsIEfBvIkfBqg");
	this.shape_1.setTransform(14.375,10.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.9);


(lib.Bateria = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_4
	this.instance = new lib.Carga1("synched",0);
	this.instance.setTransform(11.3,3.65,1,1,0,0,0,3,3.5);

	this.instance_1 = new lib.Carga2("synched",0);
	this.instance_1.setTransform(7.35,3.65,1,1,0,0,0,4,3.5);

	this.instance_2 = new lib.Carga3("synched",0);
	this.instance_2.setTransform(3.9,3.6,1,1,0,0,0,2.6,3.5);

	this.instance_3 = new lib.Carga4("synched",0);
	this.instance_3.setTransform(0.6,3.35,1,1,0,0,0,0.5,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance},{t:this.instance_1}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},10).wait(11));

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1,1,1).p("AlJizIKTAAIAAFnIqTAAg");
	this.shape.setTransform(7.746,3.5203,0.1944,0.1944);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#666666").ss(1,1,1).p("AgghoIBCAAIAADRIhCAAg");
	this.shape_1.setTransform(0.6677,3.3535,0.1944,0.1944);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,16.2,9);


(lib.Pantalla = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Bateria();
	this.instance.setTransform(254.2,26.5,1,1,0,0,0,7,3.5);

	this.instance_1 = new lib.Horizontal("synched",0);
	this.instance_1.setTransform(144.95,96.5,1,1,0,0,0,130.1,27.2);
	this.instance_1.alpha = 0.1992;

	this.instance_2 = new lib.Vertical("synched",0);
	this.instance_2.setTransform(144.95,96.55,1,1,0,0,0,43.9,81.7);
	this.instance_2.alpha = 0.5;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgHAXQgEgDgDgGQgCgFAAgJQAAgIACgFQADgGAEgDQAEgCADAAQAFAAADACQAEADADAGQACAFAAAIQAAAJgCAFQgDAGgEADQgDACgFAAQgDAAgEgCgAgCgVQgBAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAIgCAHIAAALIAAAMIACAHQAAAAAAABQAAAAABABQAAAAAAAAQAAABABAAIACABIADgBIADgDIABgHIAAgMIAAgLIgBgHIgDgDIgDgBIgCABg");
	this.shape.setTransform(222.275,168.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AACAYIAAgMIgTAAIAAgFIAVgeIAHAAIAAAdIAHAAIAAAGIgHAAIAAAMgAgNAGIAPAAIAAgWg");
	this.shape_1.setTransform(218.425,168.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s().p("AgMAUQgEgGAAgKQAAgGADgHQAEgGAHgEQAHgFAJAAIAAACQgJABgFAGQgEAEgCAJIAGgCIADgBQAFAAADACQAEACABACQACADAAAEQAAAGgDADQgCAEgEACQgFACgDAAQgHAAgGgFgAgGAAIAAAGQAAAJABAEQACAEADAAQADAAACgDQACgEAAgGQAAgIgCgCQgCgBgDgBQgDABgDABg");
	this.shape_2.setTransform(214.4,168.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s().p("AgIAYQgEgBgDgDQgEgEgCgEQgCgGAAgGQAAgGACgFQACgFAEgDQADgDAEgBQAFgCADgBQAFABAEACQAEABAEADQADADACAFQACAFAAAGQAAAGgCAGIgFAIQgEADgEABQgEACgFAAQgEAAgEgCgAgGgVQgDADgBAFIgBANIABAOQABAFADADQADACADAAQAEAAADgCQADgDABgFQABgFAAgJQAAgIgBgFQgBgFgDgDQgDgCgEAAQgDAAgDACg");
	this.shape_3.setTransform(208.175,168.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("AgJAZQgFgBgCgBIAAgLIACAAIADAFIACAEIADACIACABIADAAQADAAADgCQADgDAAgEQAAgDgCgDQgCgBgEgCIgCgBQgGgDgEgDQgEgEAAgGQAAgFACgDQADgDAEgBQAEgCAEgBIAIACIAGADIAAAJIgDAAIgCgGIgDgDIgCgBIgCgBIgCAAQgCAAgDACQgDADAAADQAAADACADIAFAEIAEACQAHADADACQADAEAAAGQAAAGgFAEQgFAFgIgBIgIgBg");
	this.shape_4.setTransform(203.725,168.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s().p("AgJAZIAAgCIACAAQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAAAIABgDIAAglIgBgDQAAAAAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAIgCAAIAAgCIASAAIAAACIgBAAIgCABIgBADIAAAlIABADIACABIABAAIAAACg");
	this.shape_5.setTransform(200.6,168.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#666666").s().p("AgHAXQgEgDgDgFQgCgGAAgJQAAgIACgFQADgGAEgCQAEgDADAAQAFAAADADQAEACADAGQACAFAAAIQAAAJgCAGQgDAFgEADQgDACgFAAQgDAAgEgCgAgCgVQgBAAAAABQAAAAgBAAQAAABAAAAQAAABAAAAIgCAHIAAALIAAAMIACAGQAAABAAABQAAAAAAABQABAAAAAAQAAABABAAIACABIADgBIADgEIABgGIAAgMIAAgLIgBgHIgDgDIgDgBIgCABg");
	this.shape_6.setTransform(175.525,168.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#666666").s().p("AgDAFQgBgBAAAAQgBgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAABQAAAAgBABQAAAAAAABQgBAAAAAAQgBABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_7.setTransform(172.525,170.425);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#666666").s().p("AgQAYIAAgFIALgLQAFgGACgDQACgEABgGQAAgEgCgDQgCgEgDAAIgEABIgDAFIgDAGIgCAAIAAgLIAGgCIAHAAQAIAAAEADQAEAEAAAFQAAAFgFAGIgMAKIgEADIgEADIAaAAIAAAIg");
	this.shape_8.setTransform(169.45,168.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#666666").s().p("AgIABIAAgBIARAAIAAABg");
	this.shape_9.setTransform(161.05,169.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#666666").s().p("AAKAZIAAgBIABgBIADgBIAAgDIAAgRIAAgTIgPAqIgDAAIgRgpIABAQIAAATIAAADIACABIABABIAAABIgLAAIAAgBIACgBIACgBIAAgEIAAgkIAAgCIgCgBIgCgBIAAgCIAPAAIANAkIAOgkIAOAAIAAACIgBAAIgCACIAAACIAAAIIAAAKIAAABIAAAJIAAAJIAAADIACABIABABIAAABg");
	this.shape_10.setTransform(156.75,168.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#666666").s().p("AAKAZIAAgBIACgBIABgBIABgDIAAgRIAAgTIgPAqIgDAAIgRgpIAAAQIAAATIABADIABABIACABIAAABIgLAAIAAgBIACgBIACgBIABgEIAAgkIgBgCIgBgBIgDgBIAAgCIAPAAIANAkIANgkIAQAAIAAACIgCAAIgCACIgBACIAAAIIAAAKIAAABIAAAJIAAAJIABADIACABIACABIAAABg");
	this.shape_11.setTransform(150.75,168.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#212121").s().p("AlLCpIAAlRIKXAAIAAFRg");
	this.shape_12.setTransform(155.8024,168.5822,0.2759,0.255);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#666666").s().p("AgJABIAAgBIATAAIAAABg");
	this.shape_13.setTransform(119.7,169.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#666666").s().p("AgIABIAAgBIASAAIAAABg");
	this.shape_14.setTransform(117.2,169.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#666666").s().p("AgSAZIAAgBIACgBIACgBIAAgDIABgJIAAgJIAAgBIAAgKIgBgIIAAgCIgCgCIgCAAIAAgCIAkAAIAAANIgBAAIgFgHIgBgDIgDAAIgKAAIAAAKIAAALIAGAAIADgBIABgCIABgEIACAAIAAAOIgCAAIgBgDIgBgDIgDgBIgGAAIAAAKIAAAJQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIABABIAAABg");
	this.shape_15.setTransform(113.9,168.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#666666").s().p("AgPAVIAAgJIACAAIACAGIAEADQACABADAAQADABADgEQACgDAAgGQAAgLgJAAIgEABIgEAAIgBAAIABgYIAaAAIAAAIIgYAAIgBANIAFgCIAFgBQAHAAAFAFQAFADgBAHQABAFgDAEQgDADgEABQgEACgFABQgJAAgEgEg");
	this.shape_16.setTransform(88.55,168.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#666666").s().p("AgPAYIAAgFIAKgLQAFgGACgDQACgEABgGQAAgEgCgDQgCgEgDAAIgEABIgDAFIgDAGIgCAAIAAgLIAGgCIAHAAQAIAAAEADQAEAEAAAFQAAAFgEAGIgNAKIgEADIgEADIAaAAIAAAIg");
	this.shape_17.setTransform(84.5,168.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#666666").s().p("AgKAhIAThBIACAAIgTBBg");
	this.shape_18.setTransform(81.125,168.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#666666").s().p("AgKAYIAAgBIADgBQAAAAABAAQABgBAAAAQAAgBABAAQAAgBAAAAIAAgjIgGAAIAAgBIAIgDIAHgDIAAAAIAAALIAAAVIAAAEIAAAGQAAAAAAABQABAAAAABQAAAAABABQABAAAAAAIADABIAAABg");
	this.shape_19.setTransform(78.525,168.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#666666").ss(1,1,1).p("EhDLgqKMCGXAAAMAAABUVMiGXAAAg");
	this.shape_20.setTransform(144.9175,96.4991,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,13.9,262.1,165.29999999999998);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [88,122];
	// timeline functions:
	this.frame_88 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Siguiente.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contenido.html', '_self');
		});
	}
	this.frame_122 = function() {
		var _this = this;
		/*
		Detener un clip de película o un vídeo
		Detiene el clip de película o el vídeo especificado.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(88).call(this.frame_88).wait(34).call(this.frame_122).wait(1));

	// Linea
	this.instance = new lib.Símbolo1("synched",0);
	this.instance.setTransform(480,361.5,1,1,0,0,0,9,1.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).to({regX:9.2,scaleX:27.8315,x:485.55},17).wait(19));

	// Mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_104 = new cjs.Graphics().p("A1McZIAAglMBOQAAAIAAAlg");
	var mask_graphics_105 = new cjs.Graphics().p("A1McZIAAhSMBORAAAIAABSg");
	var mask_graphics_106 = new cjs.Graphics().p("A1McZIAAiAMBORAAAIAACAg");
	var mask_graphics_107 = new cjs.Graphics().p("A1LcaIAAiuMBOQAAAIAACug");
	var mask_graphics_108 = new cjs.Graphics().p("A1LcaIAAjcMBORAAAIAADcg");
	var mask_graphics_109 = new cjs.Graphics().p("A1LcaIAAkJMBORAAAIAAEJg");
	var mask_graphics_110 = new cjs.Graphics().p("A1KcaIAAk3MBOQAAAIAAE3g");
	var mask_graphics_111 = new cjs.Graphics().p("A1KcbIAAlmMBORAAAIAAFmg");
	var mask_graphics_112 = new cjs.Graphics().p("A1KcbIAAmTMBORAAAIAAGTg");
	var mask_graphics_113 = new cjs.Graphics().p("A1JcbIAAnBMBOQAAAIAAHBg");
	var mask_graphics_114 = new cjs.Graphics().p("A1JcbIAAnuMBORAAAIAAHug");
	var mask_graphics_115 = new cjs.Graphics().p("A1JccIAAodMBORAAAIAAIdg");
	var mask_graphics_116 = new cjs.Graphics().p("A1IccIAApKMBORAAAIAAJKg");
	var mask_graphics_117 = new cjs.Graphics().p("A1IccIAAp4MBORAAAIAAJ4g");
	var mask_graphics_118 = new cjs.Graphics().p("A1HccIAAqlMBOQAAAIAAKlg");
	var mask_graphics_119 = new cjs.Graphics().p("A1HcdIAArUMBORAAAIAALUg");
	var mask_graphics_120 = new cjs.Graphics().p("A1HcdIAAsCMBORAAAIAAMCg");
	var mask_graphics_121 = new cjs.Graphics().p("A1GcdIAAsvMBOQAAAIAAMvg");
	var mask_graphics_122 = new cjs.Graphics().p("A1GcYIAAteMBORAAAIAANeg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(104).to({graphics:mask_graphics_104,x:365.2339,y:181.6703}).wait(1).to({graphics:mask_graphics_105,x:365.2686,y:181.6973}).wait(1).to({graphics:mask_graphics_106,x:365.3033,y:181.7243}).wait(1).to({graphics:mask_graphics_107,x:365.3381,y:181.7513}).wait(1).to({graphics:mask_graphics_108,x:365.3728,y:181.7782}).wait(1).to({graphics:mask_graphics_109,x:365.4075,y:181.8052}).wait(1).to({graphics:mask_graphics_110,x:365.4422,y:181.8322}).wait(1).to({graphics:mask_graphics_111,x:365.4769,y:181.8592}).wait(1).to({graphics:mask_graphics_112,x:365.5117,y:181.8861}).wait(1).to({graphics:mask_graphics_113,x:365.5464,y:181.9131}).wait(1).to({graphics:mask_graphics_114,x:365.5811,y:181.9401}).wait(1).to({graphics:mask_graphics_115,x:365.6158,y:181.967}).wait(1).to({graphics:mask_graphics_116,x:365.6506,y:181.994}).wait(1).to({graphics:mask_graphics_117,x:365.6853,y:182.021}).wait(1).to({graphics:mask_graphics_118,x:365.72,y:182.048}).wait(1).to({graphics:mask_graphics_119,x:365.7547,y:182.0749}).wait(1).to({graphics:mask_graphics_120,x:365.7894,y:182.1019}).wait(1).to({graphics:mask_graphics_121,x:365.8242,y:182.1289}).wait(1).to({graphics:mask_graphics_122,x:365.8589,y:181.5637}).wait(1));

	// Texto
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AiyDVQhBhQAAiDQAAhQAdhCQAdhCA4gpQA4goBJAAQBtAABEBNQBDBOAAB+QAAAtgJAsQgKArgTAnQgUAngbAdQgcAdgpARQgoARgxAAQhxAAhChPgAgokEQgVAJgTAVQgSAUgMAfQgNAegHAsQgIAtAAA2QAABMAPA+QAPA+AgAnQAgAmAsAAQBAAAAmhMQAlhMAAh+QAAiDgkhCQglhChBAAQgVAAgUAKg");
	this.shape.setTransform(690.9,318.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AhtEXIAAgSIA8gEIAAoBIg8gEIAAgSIDbAAIAAASIg8AEIAAIBIA8AEIAAASg");
	this.shape_1.setTransform(648.875,318.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s().p("AjLEXIAAgSIA7gEIAAoBIg7gEIAAgSIDbAAIAAASIg8AEIAAH9QA/AEAYAAIAlgBQARgBAOgEQANgEAJgEQAJgEAIgJQAIgKAGgIQAEgJAJgaQAIgZAGghIANAAIAACgg");
	this.shape_2.setTransform(612.8,318.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s().p("AixDVQhChQAAiDQAAhQAdhCQAdhCA4gpQA4goBJAAQBtAABDBNQBEBOAAB+QAAAtgJAsQgJArgUAnQgTAngdAdQgcAdgoARQgpARgvAAQhyAAhBhPgAgpkEQgUAJgSAVQgTAUgMAfQgNAegIAsQgHAtgBA2QAABMAQA+QAPA+AgAnQAgAmAsAAQBBAAAlhMQAlhMAAh+QAAiDgkhCQglhChAAAQgWAAgVAKg");
	this.shape_3.setTransform(561.35,318.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("Ai5EXIAAgSIA7gEIAAoBIg7gEIAAgSIFwAAIADCfIgVAAQgDgggGgYQgIgXgMgTQgOgUgYgJQgXgKgiAAQgsAAgWAEIAADwIALABQAaAAARgDQAQgDANgKQAMgJAGgTQAEgTAAgfIAWAAIAADRIgWAAQAAg2gRgVQgRgVgpAAIgeABIAAD4IBLAEIAAASg");
	this.shape_4.setTransform(512.55,318.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s().p("AAlEfIAAgSIA1gEIguiMIiuAAIguCMIA1AEIAAASIh6AAIAAgSIAvgEIC5onIARAAIC/InIAzAEIAAASgAh7BmICegEIhNjuIgCAAg");
	this.shape_5.setTransform(467.125,318.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#666666").s().p("AhsEXIAAgSIA8gEIgCoBIgJAAIgHAAQgRAAgOACQgNACgLAFQgMAGgIAGQgIAGgHAMQgHAMgFALQgFAKgFAUQgFASgMA8IgVAAIAEjAIGpAAIAEC/IgVAAIgKgwIgKgnQgGgUgGgLQgGgMgJgLQgJgLgMgFQgLgGgQgDQgPgEgUAAIgGABIgJAAIAAIBIA9AEIAAASg");
	this.shape_6.setTransform(418.675,318.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#666666").s().p("AC0EXQgeAAgRgEQgRgEgRgOQgSgOgNgYQgNgZgghPIgNgeQgJgTgGgKIgOgUQgKgKgIgFQgKgEgKAAIgbAAIAADwIA9AEIAAASIjcAAIAAgSIA7gEIAAoBIg7gEIAAgSIDQAAQAqAAAjAIQAjAHAbAQQAcAQAPAcQAPAbAAAlQAABCgtAmQgsAkhMALIAAABQAfAAAZAKQAXAKAPAQQAOAQANAZIAZA1QAPAjAQAbQANAXANAMQANAMAKADQAKACALAAIAAAWgAhUj9IAAD5IAQAAQBFAAAcgiQAdghAAhEQAAgigIgXQgIgXgPgNQgPgNgRgGQgSgFgXAAQgPAAgXADg");
	this.shape_7.setTransform(371.55,318.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#666666").s().p("AixDVQhChQAAiDQAAhQAdhCQAdhCA4gpQA4goBJAAQBtAABDBNQBEBOAAB+QAAAtgJAsQgJArgUAnQgTAngdAdQgcAdgoARQgpARgvAAQhyAAhBhPgAgpkEQgUAJgSAVQgTAUgMAfQgNAegIAsQgIAtAAA2QAABMAQA+QAPA+AgAnQAgAmAsAAQBBAAAlhMQAlhMAAh+QAAiDgkhCQglhChAAAQgWAAgVAKg");
	this.shape_8.setTransform(316.1,318.825);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#666666").s().p("AjREXIAAgSIA8gEIAAoBIg8gEIAAgSIDTAAQArAAAlAKQAkAJAdASQAeATARAfQAQAfAAApQAAAlgNAeQgNAegVAVQgVATgfANQgeAOgiAGQghAGgmAAIgZgBIAADJIA7AEIAAASgAgxj7IAAEdIAcABQB/AAAAibQAAgmgIgbQgJgbgQgOQgRgPgTgGQgUgHgZAAQgSAAgXADg");
	this.shape_9.setTransform(264.65,318.825);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},104).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},18).wait(1));

	// Diseño_Pantalla_copia
	this.instance_1 = new lib.Pantalla("synched",0);
	this.instance_1.setTransform(442.45,254.75,1,1,0,0,0,145.2,96.8);
	this.instance_1._off = true;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#898989").s().p("AgSAoIgKgIIgHgHIgDgHIgCgIIgDgIIADgGIAAgIIACgHIAFgHIAIgIIAHgFIAIgDIALAAIAAgCIASAFIAMAHIAFAIIAFAIIADAHIAAAHIAAAHIgDAHIgCAIIgFAIIgIAHIgFAFIgHACIgNADIgTgFg");
	this.shape_10.setTransform(-81.075,6.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},64).to({state:[{t:this.instance_1}]},22).to({state:[{t:this.shape_10},{t:this.instance_1}]},1).wait(36));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(64).to({_off:false},0).to({scaleX:3.1921,scaleY:3.1921,x:479.1,y:316.55},22).wait(1).to({regX:145.1,regY:96.6,scaleX:3.2917,scaleY:3.2917,x:480.7,y:319.35},0).wait(36));

	// PGrande
	this.instance_2 = new lib.PGrande("synched",0);
	this.instance_2.setTransform(403.9,385.75,1,1,0,0,0,12.2,6.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:12.3,regY:6.9,scaleX:10.9835,scaleY:10.9835,x:408.6,y:384.7},49).to({_off:true},1).wait(73));

	// Boton_Siguiente
	this.instance_3 = new lib.Boton_Sig();
	this.instance_3.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.Boton_Sig(), 3);

	this.Siguiente = new lib.Boton_Sig();
	this.Siguiente.name = "Siguiente";
	this.Siguiente.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.Siguiente, 0, 1, 2, false, new lib.Boton_Sig(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},87).to({state:[{t:this.Siguiente}]},1).wait(35));

	// Capa_1
	this.instance_4 = new lib.Camara_Fondo("synched",0);
	this.instance_4.setTransform(419.4,221.7,1,1,0,0,0,419.4,221.7);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(50).to({_off:false},0).wait(1).to({regX:481.5,regY:320.7,scaleX:1.4166,scaleY:1.4166,x:509.35,y:363.95},0).wait(1).to({scaleX:1.8333,scaleY:1.8333,x:537.25,y:407.2},0).wait(1).to({scaleX:2.2499,scaleY:2.2499,x:565.1,y:450.45},0).wait(1).to({scaleX:2.6666,scaleY:2.6666,x:592.95,y:493.65},0).wait(1).to({scaleX:3.0832,scaleY:3.0832,x:620.8,y:536.9},0).wait(1).to({scaleX:3.4999,scaleY:3.4999,x:648.65,y:580.15},0).wait(1).to({scaleX:3.9165,scaleY:3.9165,x:676.5,y:623.4},0).wait(1).to({scaleX:4.3332,scaleY:4.3332,x:704.35,y:666.65},0).wait(1).to({scaleX:4.7498,scaleY:4.7498,x:732.25,y:709.85},0).wait(1).to({scaleX:5.1665,scaleY:5.1665,x:760.1,y:753.1},0).wait(1).to({scaleX:5.5831,scaleY:5.5831,x:787.9,y:796.35},0).wait(1).to({scaleX:5.9998,scaleY:5.9998,x:815.8,y:839.55},0).wait(1).to({scaleX:6.4164,scaleY:6.4164,x:843.65,y:882.85},0).wait(1).to({scaleX:6.8331,scaleY:6.8331,x:871.5,y:926.05},0).wait(1).to({scaleX:7.2497,scaleY:7.2497,x:899.4,y:969.3},0).wait(1).to({scaleX:7.6664,scaleY:7.6664,x:927.2,y:1012.55},0).wait(1).to({scaleX:8.083,scaleY:8.083,x:955.05,y:1055.75},0).wait(1).to({scaleX:8.4997,scaleY:8.4997,x:982.95,y:1099.05},0).wait(1).to({scaleX:8.9163,scaleY:8.9163,x:1010.8,y:1142.25},0).wait(1).to({scaleX:9.3329,scaleY:9.3329,x:1038.65,y:1185.45},0).wait(1).to({scaleX:9.7496,scaleY:9.7496,x:1066.5,y:1228.75},0).wait(1).to({scaleX:10.1662,scaleY:10.1662,x:1094.35,y:1271.95},0).wait(1).to({scaleX:10.5829,scaleY:10.5829,x:1122.2,y:1315.25},0).wait(1).to({scaleX:10.9995,scaleY:10.9995,x:1150.05,y:1358.45},0).wait(1).to({scaleX:11.4162,scaleY:11.4162,x:1177.95,y:1401.65},0).wait(1).to({scaleX:11.8328,scaleY:11.8328,x:1205.75,y:1444.95},0).wait(1).to({scaleX:12.2495,scaleY:12.2495,x:1233.6,y:1488.15},0).wait(1).to({scaleX:12.6661,scaleY:12.6661,x:1261.5,y:1531.35},0).wait(1).to({scaleX:13.0828,scaleY:13.0828,x:1289.35,y:1574.65},0).wait(1).to({scaleX:13.4994,scaleY:13.4994,x:1317.2,y:1617.85},0).wait(1).to({scaleX:13.9161,scaleY:13.9161,x:1345.05,y:1661.15},0).wait(1).to({scaleX:14.3327,scaleY:14.3327,x:1372.9,y:1704.35},0).wait(1).to({scaleX:14.7494,scaleY:14.7494,x:1400.75,y:1747.55},0).wait(1).to({scaleX:15.166,scaleY:15.166,x:1428.65,y:1790.85},0).wait(1).to({scaleX:15.5827,scaleY:15.5827,x:1456.5,y:1834.05},0).wait(1).to({scaleX:15.9993,scaleY:15.9993,x:1484.3,y:1877.3},0).to({_off:true},1).wait(36));

	// Camara
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#3C3C3C").ss(1,1,1,3,true).p("AHyAAQAADOiRCTQiTCRjOAAQjOAAiSiRQiSiTAAjOQAAjOCSiSQCSiSDOAAQDOAACTCSQCRCSAADOg");
	this.shape_11.setTransform(655.35,382.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#333333").s().p("AlfFgQiTiSABjOQgBjOCTiRQCRiSDOAAQDPAACRCSQCTCRAADOQAADOiTCSQiRCSjPAAQjOAAiRiSg");
	this.shape_12.setTransform(655.35,382.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_13.setTransform(689.5,454.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_14.setTransform(620.2,455.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_15.setTransform(689.55,306.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#212121").s().p("AhSBTQgigjAAgwQAAgwAigiQAjgiAvgBQAwABAjAiQAiAiABAwQgBAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_16.setTransform(620.25,306.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_17.setTransform(678.8,235.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_18.setTransform(640.7,235.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_19.setTransform(320.35,234.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#121212").s().p("AhFBFQgcgcAAgpQAAgoAcgdQAdgcAoAAQAoAAAdAcQAdAdAAAoQAAApgdAcQgdAdgoAAQgoAAgdgdg");
	this.shape_20.setTransform(285.25,235.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#121212").s().p("AlLDgIAAnAIKXAAIAAHAg");
	this.shape_21.setTransform(418,223.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#212121").s().p("Am7E0QhFAAAAhFIAAndQAAhFBFAAIN3AAQBFAAAABFIAAHdQAABFhFAAg");
	this.shape_22.setTransform(418.625,222.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#333333").s().p("AoTGfQi6AAAAi5IAAnLQAAi5C6AAIQnAAQC6AAAAC5IAAHLQAAC5i6AAg");
	this.shape_23.setTransform(417.55,217.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#454545").s().p("ArISZMAAAgkxIWRAAMAAAAkxg");
	this.shape_24.setTransform(653.8,379.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#121212").s().p("A0+LwIAA3fMAp9AAAIAAXfg");
	this.shape_25.setTransform(406.8,383.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#212121").s().p("A2lOHIAA8NMAtLAAAIAAcNg");
	this.shape_26.setTransform(406.3,384.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#333333").s().p("A7ESeMAAAgk7MA2KAAAMAAAAk7g");
	this.shape_27.setTransform(410.7236,381.1892,0.9943,0.9834);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3C3C3C").s().p("EgjgAWNQifAAAAieMAAAgndQAAieCfAAMBHBAAAQCfAAAACeMAAAAndQAACeifAAg");
	this.shape_28.setTransform(481.5,355.075);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#E7E7E7").s().p("EhLNAhOMAAAhCbMCWbAAAMAAABCbg");
	this.shape_29.setTransform(481.45,212.625);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#4A3829").s().p("EhK/ARHMAAAgiNMCV/AAAMAAAAiNg");
	this.shape_30.setTransform(479.975,531.825);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#121212").s().p("EhK/AyFMAAAhkJMCV/AAAMAAABkJg");
	this.shape_31.setTransform(479.975,320.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11}]}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11}]},49).to({state:[]},1).to({state:[{t:this.shape_31}]},37).wait(36));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-5739.3,-2933.6,14925.7,9940.3);
// library properties:
lib.properties = {
	id: '03E86B4BEFE3A746A5A93EC7110CE018',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['03E86B4BEFE3A746A5A93EC7110CE018'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;