(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"planeta_verde_tarjetadepresentacion_atlas_1", frames: [[824,1084,171,76],[0,1243,74,76],[373,1141,104,76],[98,1165,120,57],[76,1243,68,76],[0,1165,96,76],[0,0,1719,1082],[146,1224,54,62],[301,1165,47,62],[220,1165,79,79],[479,1141,98,51],[373,1084,449,55],[0,1084,371,79]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_524 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_523 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_522 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_521 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_520 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_519 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_518 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_517 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_515 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_516 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_513 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_512 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_511 = function() {
	this.initialize(ss["planeta_verde_tarjetadepresentacion_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.TarjetaPv = function() {
	this.initialize(img.TarjetaPv);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4400,3000);


(lib.Vertical = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EgWpgqKMAtTAAAMAAABUVMgtTAAAg");
	this.shape.setTransform(43.86,81.6491,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,89.8,165.3);


(lib.Linea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#898989").s().p("AvmAPIAAgdIfNAAIAAAdg");
	this.shape.setTransform(106.1313,1.5,1.0623,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,212.3,3);


(lib.Imagen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.TarjetaPv();
	this.instance.setTransform(0,0,0.2233,0.2233);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,982.5,669.9);


(lib.Iconos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_517();
	this.instance.setTransform(50.45,3.6,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_516();
	this.instance_1.setTransform(43.95,-1,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_515();
	this.instance_2.setTransform(6.7,3.6,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_516();
	this.instance_3.setTransform(-0.95,-1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.9,-1,84.4,39.5);


(lib.Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EhDLgODMCGXAAAIAAcHMiGXAAAg");
	this.shape.setTransform(130.0675,27.2142,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,262.2,56.5);


(lib.Carga4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape.setTransform(0.5,2.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1,4.1);


(lib.Carga3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgZAjIAAhFIAzAAIggBFg");
	this.shape.setTransform(2.6,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.9);


(lib.Carga2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgoAjIAihFIAvAAIgiBFg");
	this.shape.setTransform(4.075,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,8.2,6.9);


(lib.Carga1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgdAjIAhhFIAaAAIAABFg");
	this.shape.setTransform(2.975,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6,6.9);


(lib.Boton_Sig = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiPhsIEfBvIkfBqg");
	this.shape.setTransform(14.375,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiPhsIEfBvIkfBqg");
	this.shape_1.setTransform(14.375,10.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.9);


(lib.Boton_Contenido = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape.setTransform(14.475,10.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape_1.setTransform(14.475,10.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,29,22);


(lib.Boton_Atras = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape.setTransform(14.4,10.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape_1.setTransform(14.4,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.8);


(lib.Bateria = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_4
	this.instance = new lib.Carga1("synched",0);
	this.instance.setTransform(11.3,3.65,1,1,0,0,0,3,3.5);

	this.instance_1 = new lib.Carga2("synched",0);
	this.instance_1.setTransform(7.35,3.65,1,1,0,0,0,4,3.5);

	this.instance_2 = new lib.Carga3("synched",0);
	this.instance_2.setTransform(3.9,3.6,1,1,0,0,0,2.6,3.5);

	this.instance_3 = new lib.Carga4("synched",0);
	this.instance_3.setTransform(0.6,3.35,1,1,0,0,0,0.5,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance},{t:this.instance_1}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},10).wait(11));

	// Capa_1
	this.instance_4 = new lib.CachedBmp_513();
	this.instance_4.setTransform(-0.35,-0.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.3,14.9,7.7);


(lib.Pantalla = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Bateria();
	this.instance.setTransform(254.2,26.5,1,1,0,0,0,7,3.5);

	this.instance_1 = new lib.Horizontal("synched",0);
	this.instance_1.setTransform(144.95,96.5,1,1,0,0,0,130.1,27.2);
	this.instance_1.alpha = 0.0703;

	this.instance_2 = new lib.Vertical("synched",0);
	this.instance_2.setTransform(144.95,96.55,1,1,0,0,0,43.9,81.7);
	this.instance_2.alpha = 0.0703;

	this.instance_3 = new lib.CachedBmp_524();
	this.instance_3.setTransform(198.85,162.7,0.1519,0.1519);

	this.instance_4 = new lib.CachedBmp_523();
	this.instance_4.setTransform(166.75,162.5,0.1519,0.1519);

	this.instance_5 = new lib.CachedBmp_522();
	this.instance_5.setTransform(147.1,162.5,0.1519,0.1519);

	this.instance_6 = new lib.CachedBmp_521();
	this.instance_6.setTransform(146.6,164.25,0.1519,0.1519);

	this.instance_7 = new lib.CachedBmp_520();
	this.instance_7.setTransform(111.25,162.5,0.1519,0.1519);

	this.instance_8 = new lib.CachedBmp_519();
	this.instance_8.setTransform(76.55,162.5,0.1519,0.1519);

	this.instance_9 = new lib.CachedBmp_518();
	this.instance_9.setTransform(14.35,14.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,13.9,262.1,165.29999999999998);


// stage content:
(lib.planeta_verde_tarjetadepresentacion = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,36];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Atras.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('planeta_verde_heroe.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Contenido.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contenido.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Sig.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('planeta_verde_folleto.html', '_self');
		});
	}
	this.frame_36 = function() {
		var _this = this;
		/*
		Detener un clip de película o un vídeo
		Detiene el clip de película o el vídeo especificado.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(36).call(this.frame_36).wait(1));

	// Borde_Negro
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("EhC7gqrMCF3AAAMAAABUlMiF3AAAgEhLAgyKMCWBAAAMAAABkVMiWBAAAg");
	this.shape.setTransform(480.15,321.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#121212").s().p("EhLAAyLMAAAhkVMCWBAAAMAAABkVgEhC7Ap6MCF2AAAMAAAhUlMiF2AAAg");
	this.shape_1.setTransform(480.15,321.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(37));

	// M_Text (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AwkJ8IAAn0MAhJAAAIAAH0g");
	var mask_graphics_15 = new cjs.Graphics().p("AwnJ9IAAn3MAhPAAAIAAH3g");
	var mask_graphics_16 = new cjs.Graphics().p("AwqJ+IAAn6MAhVAAAIAAH6g");
	var mask_graphics_17 = new cjs.Graphics().p("AwsKAIAAn+MAhZAAAIAAH+g");
	var mask_graphics_18 = new cjs.Graphics().p("AwvKBIAAoBMAhfAAAIAAIBg");
	var mask_graphics_19 = new cjs.Graphics().p("AwyKCIAAoDMAhlAAAIAAIDg");
	var mask_graphics_20 = new cjs.Graphics().p("Aw1KDIAAoGMAhrAAAIAAIGg");
	var mask_graphics_21 = new cjs.Graphics().p("Aw3KEIAAoJMAhvAAAIAAIJg");
	var mask_graphics_22 = new cjs.Graphics().p("Aw6KFIAAoMMAh1AAAIAAIMg");
	var mask_graphics_23 = new cjs.Graphics().p("Aw9KGIAAoPMAh7AAAIAAIPg");
	var mask_graphics_24 = new cjs.Graphics().p("AxAKHIAAoSMAiBAAAIAAISg");
	var mask_graphics_25 = new cjs.Graphics().p("AxCKIIAAoVMAiFAAAIAAIVg");
	var mask_graphics_26 = new cjs.Graphics().p("AwtKJIAAoYMAiLAAAIAAIYg");
	var mask_graphics_27 = new cjs.Graphics().p("AwAKKIAAobMAiRAAAIAAIbg");
	var mask_graphics_28 = new cjs.Graphics().p("AvTKLIAAoeMAiXAAAIAAIeg");
	var mask_graphics_29 = new cjs.Graphics().p("AulKMIAAohMAicAAAIAAIhg");
	var mask_graphics_30 = new cjs.Graphics().p("At4KOIAAolMAiiAAAIAAIlg");
	var mask_graphics_31 = new cjs.Graphics().p("AtKKPIAAooMAinAAAIAAIog");
	var mask_graphics_32 = new cjs.Graphics().p("AsdKQIAAorMAitAAAIAAIrg");
	var mask_graphics_33 = new cjs.Graphics().p("ArvKRIAAouMAiyAAAIAAIug");
	var mask_graphics_34 = new cjs.Graphics().p("ArCKSIAAoxMAi4AAAIAAIxg");
	var mask_graphics_35 = new cjs.Graphics().p("AqUKTIAAo0MAi9AAAIAAI0g");
	var mask_graphics_36 = new cjs.Graphics().p("ApnKUIAAo3MAjCAAAIAAI3g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:-4.9187,y:63.625}).wait(1).to({graphics:mask_graphics_15,x:5.004,y:63.7333}).wait(1).to({graphics:mask_graphics_16,x:14.9268,y:63.8416}).wait(1).to({graphics:mask_graphics_17,x:24.8496,y:63.9498}).wait(1).to({graphics:mask_graphics_18,x:34.7724,y:64.0581}).wait(1).to({graphics:mask_graphics_19,x:44.6952,y:64.1664}).wait(1).to({graphics:mask_graphics_20,x:54.618,y:64.2746}).wait(1).to({graphics:mask_graphics_21,x:64.5408,y:64.3829}).wait(1).to({graphics:mask_graphics_22,x:74.4636,y:64.4912}).wait(1).to({graphics:mask_graphics_23,x:84.3864,y:64.5994}).wait(1).to({graphics:mask_graphics_24,x:94.3092,y:64.7077}).wait(1).to({graphics:mask_graphics_25,x:104.232,y:64.816}).wait(1).to({graphics:mask_graphics_26,x:111.7865,y:64.9243}).wait(1).to({graphics:mask_graphics_27,x:116.8853,y:65.0325}).wait(1).to({graphics:mask_graphics_28,x:121.9842,y:65.1408}).wait(1).to({graphics:mask_graphics_29,x:127.083,y:65.2491}).wait(1).to({graphics:mask_graphics_30,x:132.1819,y:65.3573}).wait(1).to({graphics:mask_graphics_31,x:137.2807,y:65.4656}).wait(1).to({graphics:mask_graphics_32,x:142.3796,y:65.5739}).wait(1).to({graphics:mask_graphics_33,x:147.4784,y:65.6822}).wait(1).to({graphics:mask_graphics_34,x:152.5773,y:65.7904}).wait(1).to({graphics:mask_graphics_35,x:157.6761,y:65.8987}).wait(1).to({graphics:mask_graphics_36,x:162.7486,y:66.007}).wait(1));

	// Texto
	this.instance = new lib.CachedBmp_512();
	this.instance.setTransform(112.5,103.25,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_511();
	this.instance_1.setTransform(112.95,70.7,0.5,0.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},14).wait(23));

	// M_Icon (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_14 = new cjs.Graphics().p("AnVD1IAAnpIOrAAIAAHpg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_1_graphics_14,x:816,y:507.4}).wait(23));

	// Iconos
	this.instance_2 = new lib.Iconos("synched",0);
	this.instance_2.setTransform(907.45,507.4,1,1,0,0,0,41.3,18.8);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({x:820.45},16).wait(7));

	// Linea
	this.instance_3 = new lib.Linea("synched",0);
	this.instance_3.setTransform(103.1,103.35,0.0164,1,-89.9423,0,0,106.5,1.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({regX:106,regY:1.6,scaleX:0.2938,x:103.05,y:103.4},6).wait(22));

	// Diseño
	this.instance_4 = new lib.Pantalla("synched",0);
	this.instance_4.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_5 = new lib.Pantalla("synched",0);
	this.instance_5.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_6 = new lib.Pantalla("synched",0);
	this.instance_6.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_7 = new lib.Pantalla("synched",0);
	this.instance_7.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4}]}).wait(37));

	// Boton_Atras
	this.Atras = new lib.Boton_Atras();
	this.Atras.name = "Atras";
	this.Atras.setTransform(100.65,542.95);
	new cjs.ButtonHelper(this.Atras, 0, 1, 2, false, new lib.Boton_Atras(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Atras).wait(37));

	// Boton_Cont
	this.Contenido = new lib.Boton_Contenido();
	this.Contenido.name = "Contenido";
	this.Contenido.setTransform(152.55,553.8,1,1,0,0,0,14.5,11);
	new cjs.ButtonHelper(this.Contenido, 0, 1, 2, false, new lib.Boton_Contenido(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Contenido).wait(37));

	// Boton_Sig
	this.Sig = new lib.Boton_Sig();
	this.Sig.name = "Sig";
	this.Sig.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.Sig, 0, 1, 2, false, new lib.Boton_Sig(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sig).wait(37));

	// Gris
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#333333").ss(1,1,1).p("EhDwgqhMCHiAAAMAAABVDMiHiAAAg");
	this.shape_2.setTransform(481.8,316.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#121212").s().p("EhDwAqiMAAAhVCMCHiAAAMAAABVCg");
	this.shape_3.setTransform(481.8,316.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[]},1).wait(36));

	// Imagen
	this.instance_8 = new lib.Imagen("synched",0);
	this.instance_8.setTransform(485.2,304.9,1,1,0,0,0,491.2,334.9);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({alpha:1},14).wait(23));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(474,290,502.5,353.29999999999995);
// library properties:
lib.properties = {
	id: 'A7B9E1DE34AE9C468571C1F532CD0EF5',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/TarjetaPv.jpg?1655441260610", id:"TarjetaPv"},
		{src:"images/planeta_verde_tarjetadepresentacion_atlas_1.png?1655441260492", id:"planeta_verde_tarjetadepresentacion_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A7B9E1DE34AE9C468571C1F532CD0EF5'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;