(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"perfil_atlas_1", frames: [[0,0,1719,1082],[0,1084,1292,578],[0,1664,1040,233]]},
		{name:"perfil_atlas_2", frames: [[0,0,1029,233],[1031,0,998,233],[0,235,970,233],[972,235,958,233],[0,470,939,233],[941,470,909,233],[0,705,892,233],[894,705,892,233],[0,940,892,233],[894,940,892,233],[0,1175,892,233],[894,1175,892,233],[0,1410,892,233],[0,1645,892,233],[894,1410,892,233],[894,1645,892,233]]},
		{name:"perfil_atlas_3", frames: [[0,0,892,233],[894,0,892,233],[0,235,892,233],[894,235,892,233],[0,470,892,233],[894,470,892,233],[0,705,892,233],[894,705,892,233],[0,940,892,233],[894,940,892,233],[0,1175,892,233],[894,1175,892,233],[0,1410,892,233],[0,1645,892,233],[894,1410,892,233],[894,1645,892,233]]},
		{name:"perfil_atlas_4", frames: [[609,1210,71,81],[1865,1625,69,81],[1788,1326,171,76],[1961,1326,74,76],[924,1595,104,76],[182,1624,120,57],[1936,1625,68,76],[1655,1570,96,76],[883,470,1057,96],[523,1624,62,81],[1374,1627,98,51],[364,1624,79,81],[1310,1627,62,81],[1942,453,103,103],[1386,1456,407,55],[274,1510,392,55],[1386,1513,370,55],[668,1538,356,55],[1026,1538,334,55],[274,1567,312,55],[1362,1570,291,55],[1788,396,258,55],[1795,1486,224,55],[890,1312,202,55],[0,1572,180,55],[776,1595,146,55],[1178,1595,130,55],[1753,1625,110,55],[1474,1627,80,55],[1556,1627,64,55],[1994,1210,49,55],[686,1128,28,55],[588,1595,186,50],[1030,1595,146,50],[738,628,133,50],[680,1394,207,50],[0,0,892,233],[894,0,892,233],[0,235,892,233],[894,235,892,233],[0,470,881,156],[645,800,853,80],[0,882,841,80],[843,882,808,80],[0,964,777,80],[0,1046,729,80],[1320,964,717,80],[1320,1046,699,80],[0,1128,684,80],[1201,1128,653,80],[0,1210,607,80],[1106,1210,563,80],[1500,800,532,80],[1106,1292,520,80],[396,1312,492,80],[890,1374,463,80],[1355,1374,431,80],[680,1456,399,80],[1653,882,368,80],[0,1408,349,80],[1081,1456,303,80],[0,1490,272,80],[1788,116,240,80],[1788,314,201,80],[1856,1128,189,80],[1795,1404,156,80],[1758,1543,126,80],[1886,1543,126,80],[1953,1404,95,80],[445,1624,76,80],[1991,314,44,80],[883,568,785,114],[0,628,736,114],[738,684,687,114],[0,744,643,114],[1427,684,598,114],[779,964,539,114],[731,1080,468,114],[686,1196,418,114],[0,1292,394,114],[1670,568,369,114],[1671,1210,321,114],[396,1394,282,114],[1788,0,238,114],[1788,198,151,114],[1941,198,107,114],[304,1624,58,114]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_211 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_209 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_207 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_206 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_205 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_204 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_203 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_202 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_201 = function() {
	this.initialize(ss["perfil_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_200 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_198 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_197 = function() {
	this.initialize(ss["perfil_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_196 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_195 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_193 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_210 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_191 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_190 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_189 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_188 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_187 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_186 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_185 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_184 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_183 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_182 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_181 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_180 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_179 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_178 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_177 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_176 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_175 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_174 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_173 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_172 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_171 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_170 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_169 = function() {
	this.initialize(ss["perfil_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_168 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_167 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_166 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_165 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_164 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_163 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_162 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_161 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_160 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_159 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_158 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_157 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_156 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_155 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_154 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_153 = function() {
	this.initialize(ss["perfil_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_152 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_151 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_150 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_149 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_148 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_147 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_146 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_145 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_144 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_143 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_142 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_141 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_140 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_139 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_138 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_137 = function() {
	this.initialize(ss["perfil_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_136 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_135 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_134 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_133 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_132 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_131 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_130 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_129 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_128 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_127 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_126 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_125 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_124 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_123 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_122 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_121 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_120 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_119 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_106 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_105 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_103 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["perfil_atlas_4"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.Vertical = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EgWpgqKMAtTAAAMAAABUVMgtTAAAg");
	this.shape.setTransform(43.86,81.6491,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,89.8,165.3);


(lib.Ps = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_211();
	this.instance.setTransform(-17.6,-19.95,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_210();
	this.instance_1.setTransform(-25.8,-25.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.8,-25.7,51.5,51.5);


(lib.Pr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_209();
	this.instance.setTransform(7.1,4.35,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_210();
	this.instance_1.setTransform(-1,-0.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.9,51.5,51.5);


(lib.Ilustr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_200();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,528.5,48);


(lib.Id = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_210();
	this.instance.setTransform(-1,-0.95,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_198();
	this.instance_1.setTransform(8.7,4.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.9,51.5,51.5);


(lib.Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EhDLgODMCGXAAAIAAcHMiGXAAAg");
	this.shape.setTransform(130.0675,27.2142,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,262.2,56.5);


(lib.Hola = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_197();
	this.instance.setTransform(0,0,0.1093,0.1093);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,141.2,63.2);


(lib.Carga4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape.setTransform(0.5,2.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1,4.1);


(lib.Carga3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgZAjIAAhFIAzAAIggBFg");
	this.shape.setTransform(2.6,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.9);


(lib.Carga2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgoAjIAihFIAvAAIgiBFg");
	this.shape.setTransform(4.075,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,8.2,6.9);


(lib.Carga1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgdAjIAhhFIAaAAIAABFg");
	this.shape.setTransform(2.975,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6,6.9);


(lib.Boton_Sig = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiPhsIEfBvIkfBqg");
	this.shape.setTransform(14.375,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiPhsIEfBvIkfBqg");
	this.shape_1.setTransform(14.375,10.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.9);


(lib.Boton_Contenido = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape.setTransform(14.475,10.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape_1.setTransform(14.475,10.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,29,22);


(lib.Boton_Atras = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape.setTransform(14.4,10.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape_1.setTransform(14.4,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.8);


(lib.An = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_195();
	this.instance.setTransform(4.05,4.2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_210();
	this.instance_1.setTransform(-1,-0.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.9,51.5,51.5);


(lib.Ai = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_193();
	this.instance.setTransform(8.85,4.85,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_210();
	this.instance_1.setTransform(-1,-0.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-0.9,51.5,51.5);


(lib.Bateria = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_4
	this.instance = new lib.Carga1("synched",0);
	this.instance.setTransform(11.3,3.65,1,1,0,0,0,3,3.5);

	this.instance_1 = new lib.Carga2("synched",0);
	this.instance_1.setTransform(7.35,3.65,1,1,0,0,0,4,3.5);

	this.instance_2 = new lib.Carga3("synched",0);
	this.instance_2.setTransform(3.9,3.6,1,1,0,0,0,2.6,3.5);

	this.instance_3 = new lib.Carga4("synched",0);
	this.instance_3.setTransform(0.6,3.35,1,1,0,0,0,0.5,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance},{t:this.instance_1}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},10).wait(11));

	// Capa_1
	this.instance_4 = new lib.CachedBmp_196();
	this.instance_4.setTransform(-0.35,-0.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.3,14.9,7.7);


(lib.Pantalla = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Bateria();
	this.instance.setTransform(254.2,26.5,1,1,0,0,0,7,3.5);

	this.instance_1 = new lib.Horizontal("synched",0);
	this.instance_1.setTransform(144.95,96.5,1,1,0,0,0,130.1,27.2);
	this.instance_1.alpha = 0.0703;

	this.instance_2 = new lib.Vertical("synched",0);
	this.instance_2.setTransform(144.95,96.55,1,1,0,0,0,43.9,81.7);
	this.instance_2.alpha = 0.0703;

	this.instance_3 = new lib.CachedBmp_207();
	this.instance_3.setTransform(198.85,162.7,0.1519,0.1519);

	this.instance_4 = new lib.CachedBmp_206();
	this.instance_4.setTransform(166.75,162.5,0.1519,0.1519);

	this.instance_5 = new lib.CachedBmp_205();
	this.instance_5.setTransform(147.1,162.5,0.1519,0.1519);

	this.instance_6 = new lib.CachedBmp_204();
	this.instance_6.setTransform(146.6,164.25,0.1519,0.1519);

	this.instance_7 = new lib.CachedBmp_203();
	this.instance_7.setTransform(111.25,162.5,0.1519,0.1519);

	this.instance_8 = new lib.CachedBmp_202();
	this.instance_8.setTransform(76.55,162.5,0.1519,0.1519);

	this.instance_9 = new lib.CachedBmp_201();
	this.instance_9.setTransform(14.35,14.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,13.9,262.1,165.29999999999998);


// stage content:
(lib.perfil = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,273];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Atras.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contenido.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Contenido.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contenido.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Sig.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('educacion.html', '_self');
		});
	}
	this.frame_273 = function() {
		var _this = this;
		/*
		Detener un clip de película o un vídeo
		Detiene el clip de película o el vídeo especificado.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(273).call(this.frame_273).wait(1));

	// Hola
	this.instance = new lib.Hola("synched",0);
	this.instance.setTransform(480.05,320.05,0.2089,0.2089,0,0,0,70.6,31.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:70.7,regY:31.7,scaleX:4.5763,scaleY:4.5763,x:480.7,y:320.85},14).to({regX:70.6,regY:31.6,scaleX:1.0594,scaleY:1.0594,x:483.35,y:155.45},15).wait(245));

	// Nombre
	this.instance_1 = new lib.CachedBmp_86();
	this.instance_1.setTransform(295.45,177,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_87();
	this.instance_2.setTransform(295.45,177,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_88();
	this.instance_3.setTransform(295.45,177,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_89();
	this.instance_4.setTransform(295.45,177,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_90();
	this.instance_5.setTransform(295.45,177,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_91();
	this.instance_6.setTransform(295.45,177,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_92();
	this.instance_7.setTransform(295.45,177,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_93();
	this.instance_8.setTransform(295.45,177,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_94();
	this.instance_9.setTransform(295.45,177,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_95();
	this.instance_10.setTransform(295.45,177,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_96();
	this.instance_11.setTransform(295.45,177,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_97();
	this.instance_12.setTransform(295.45,177,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_98();
	this.instance_13.setTransform(295.45,177,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_99();
	this.instance_14.setTransform(295.45,177,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_100();
	this.instance_15.setTransform(295.45,177,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_101();
	this.instance_16.setTransform(295.45,177,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},29).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_16}]},2).wait(215));

	// Descp
	this.instance_17 = new lib.CachedBmp_102();
	this.instance_17.setTransform(469.1,239.85,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_103();
	this.instance_18.setTransform(461,239.85,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_104();
	this.instance_19.setTransform(456.3,239.85,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_105();
	this.instance_20.setTransform(448.6,239.85,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_106();
	this.instance_21.setTransform(448.6,239.85,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_107();
	this.instance_22.setTransform(440.95,239.85,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_108();
	this.instance_23.setTransform(432.75,239.85,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_109();
	this.instance_24.setTransform(429.75,239.85,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_110();
	this.instance_25.setTransform(420.05,239.85,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_111();
	this.instance_26.setTransform(411.9,239.85,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_112();
	this.instance_27.setTransform(404.2,239.85,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_113();
	this.instance_28.setTransform(392.8,239.85,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_114();
	this.instance_29.setTransform(388.1,239.85,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_115();
	this.instance_30.setTransform(380.3,239.85,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_116();
	this.instance_31.setTransform(372.15,239.85,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_117();
	this.instance_32.setTransform(364.3,239.85,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_118();
	this.instance_33.setTransform(357.1,239.85,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_119();
	this.instance_34.setTransform(349.9,239.85,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_120();
	this.instance_35.setTransform(346.9,239.85,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_121();
	this.instance_36.setTransform(339.15,239.85,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_122();
	this.instance_37.setTransform(328.15,239.85,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_123();
	this.instance_38.setTransform(316.8,239.85,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_124();
	this.instance_39.setTransform(309,239.85,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_125();
	this.instance_40.setTransform(305.25,239.85,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_126();
	this.instance_41.setTransform(300.7,239.85,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_127();
	this.instance_42.setTransform(297.7,239.85,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_128();
	this.instance_43.setTransform(285.7,239.85,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_129();
	this.instance_44.setTransform(278,239.85,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_130();
	this.instance_45.setTransform(269.85,239.85,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_131();
	this.instance_46.setTransform(266.85,239.85,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_132();
	this.instance_47.setTransform(259.65,239.85,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_133();
	this.instance_48.setTransform(256.9,239.85,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_134();
	this.instance_49.setTransform(256.9,239.85,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_135();
	this.instance_50.setTransform(256.9,239.85,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_136();
	this.instance_51.setTransform(256.9,239.85,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_137();
	this.instance_52.setTransform(256.9,239.85,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_138();
	this.instance_53.setTransform(256.9,239.85,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_139();
	this.instance_54.setTransform(256.9,239.85,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_140();
	this.instance_55.setTransform(256.9,239.85,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_141();
	this.instance_56.setTransform(256.9,239.85,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_142();
	this.instance_57.setTransform(256.9,239.85,0.5,0.5);

	this.instance_58 = new lib.CachedBmp_143();
	this.instance_58.setTransform(256.9,239.85,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_144();
	this.instance_59.setTransform(256.9,239.85,0.5,0.5);

	this.instance_60 = new lib.CachedBmp_145();
	this.instance_60.setTransform(256.9,239.85,0.5,0.5);

	this.instance_61 = new lib.CachedBmp_146();
	this.instance_61.setTransform(256.9,239.85,0.5,0.5);

	this.instance_62 = new lib.CachedBmp_147();
	this.instance_62.setTransform(256.9,239.85,0.5,0.5);

	this.instance_63 = new lib.CachedBmp_148();
	this.instance_63.setTransform(256.9,239.85,0.5,0.5);

	this.instance_64 = new lib.CachedBmp_149();
	this.instance_64.setTransform(256.9,239.85,0.5,0.5);

	this.instance_65 = new lib.CachedBmp_150();
	this.instance_65.setTransform(256.9,239.85,0.5,0.5);

	this.instance_66 = new lib.CachedBmp_151();
	this.instance_66.setTransform(256.9,239.85,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_152();
	this.instance_67.setTransform(256.9,239.85,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_153();
	this.instance_68.setTransform(256.9,239.85,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_154();
	this.instance_69.setTransform(256.9,239.85,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_155();
	this.instance_70.setTransform(256.9,239.85,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_156();
	this.instance_71.setTransform(256.9,239.85,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_157();
	this.instance_72.setTransform(256.9,239.85,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_158();
	this.instance_73.setTransform(256.9,239.85,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_159();
	this.instance_74.setTransform(256.9,239.85,0.5,0.5);

	this.instance_75 = new lib.CachedBmp_160();
	this.instance_75.setTransform(256.9,239.85,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_161();
	this.instance_76.setTransform(256.9,239.85,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_162();
	this.instance_77.setTransform(256.9,239.85,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_163();
	this.instance_78.setTransform(252.85,239.85,0.5,0.5);

	this.instance_79 = new lib.CachedBmp_164();
	this.instance_79.setTransform(245.2,239.85,0.5,0.5);

	this.instance_80 = new lib.CachedBmp_165();
	this.instance_80.setTransform(240.6,239.85,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_166();
	this.instance_81.setTransform(237.6,239.85,0.5,0.5);

	this.instance_82 = new lib.CachedBmp_167();
	this.instance_82.setTransform(230.4,239.85,0.5,0.5);

	this.instance_83 = new lib.CachedBmp_168();
	this.instance_83.setTransform(222.65,239.85,0.5,0.5);

	this.instance_84 = new lib.CachedBmp_169();
	this.instance_84.setTransform(220,239.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_17}]},59).to({state:[{t:this.instance_18}]},2).to({state:[{t:this.instance_19}]},2).to({state:[{t:this.instance_20}]},2).to({state:[{t:this.instance_21}]},2).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_24}]},2).to({state:[{t:this.instance_25}]},2).to({state:[{t:this.instance_26}]},2).to({state:[{t:this.instance_27}]},2).to({state:[{t:this.instance_28}]},2).to({state:[{t:this.instance_29}]},2).to({state:[{t:this.instance_30}]},2).to({state:[{t:this.instance_31}]},2).to({state:[{t:this.instance_32}]},2).to({state:[{t:this.instance_33}]},2).to({state:[{t:this.instance_34}]},2).to({state:[{t:this.instance_35}]},2).to({state:[{t:this.instance_36}]},2).to({state:[{t:this.instance_37}]},2).to({state:[{t:this.instance_38}]},2).to({state:[{t:this.instance_39}]},2).to({state:[{t:this.instance_40}]},2).to({state:[{t:this.instance_41}]},2).to({state:[{t:this.instance_42}]},2).to({state:[{t:this.instance_43}]},2).to({state:[{t:this.instance_44}]},2).to({state:[{t:this.instance_45}]},2).to({state:[{t:this.instance_46}]},2).to({state:[{t:this.instance_47}]},2).to({state:[{t:this.instance_48}]},2).to({state:[{t:this.instance_49}]},2).to({state:[{t:this.instance_50}]},2).to({state:[{t:this.instance_51}]},2).to({state:[{t:this.instance_52}]},2).to({state:[{t:this.instance_53}]},2).to({state:[{t:this.instance_54}]},2).to({state:[{t:this.instance_55}]},2).to({state:[{t:this.instance_56}]},2).to({state:[{t:this.instance_57}]},2).to({state:[{t:this.instance_58}]},2).to({state:[{t:this.instance_59}]},2).to({state:[{t:this.instance_60}]},2).to({state:[{t:this.instance_61}]},2).to({state:[{t:this.instance_62}]},2).to({state:[{t:this.instance_63}]},2).to({state:[{t:this.instance_64}]},2).to({state:[{t:this.instance_65}]},2).to({state:[{t:this.instance_66}]},2).to({state:[{t:this.instance_67}]},2).to({state:[{t:this.instance_68}]},2).to({state:[{t:this.instance_69}]},2).to({state:[{t:this.instance_70}]},2).to({state:[{t:this.instance_71}]},2).to({state:[{t:this.instance_72}]},2).to({state:[{t:this.instance_73}]},2).to({state:[{t:this.instance_74}]},2).to({state:[{t:this.instance_75}]},2).to({state:[{t:this.instance_76}]},2).to({state:[{t:this.instance_77}]},2).to({state:[{t:this.instance_78}]},2).to({state:[{t:this.instance_79}]},2).to({state:[{t:this.instance_80}]},2).to({state:[{t:this.instance_81}]},2).to({state:[{t:this.instance_82}]},2).to({state:[{t:this.instance_83}]},2).to({state:[{t:this.instance_84}]},2).wait(81));

	// M_Fort (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_193 = new cjs.Graphics().p("EgtpABoIAAjPMBbTAAAIAADPg");
	var mask_graphics_194 = new cjs.Graphics().p("EgtpABoIAAjPMBbTAAAIAADPg");
	var mask_graphics_195 = new cjs.Graphics().p("EgtpABoIAAjPMBbTAAAIAADPg");
	var mask_graphics_196 = new cjs.Graphics().p("EgtpABoIAAjPMBbTAAAIAADPg");
	var mask_graphics_197 = new cjs.Graphics().p("EgtpABoIAAjPMBbTAAAIAADPg");
	var mask_graphics_198 = new cjs.Graphics().p("EgtpABoIAAjPMBbTAAAIAADPg");
	var mask_graphics_199 = new cjs.Graphics().p("EgtpABoIAAjPMBbTAAAIAADPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(193).to({graphics:mask_graphics_193,x:485.3749,y:311.8252}).wait(1).to({graphics:mask_graphics_194,x:485.3749,y:315.8248}).wait(1).to({graphics:mask_graphics_195,x:485.3749,y:319.8249}).wait(1).to({graphics:mask_graphics_196,x:485.3749,y:323.8249}).wait(1).to({graphics:mask_graphics_197,x:485.3749,y:327.825}).wait(1).to({graphics:mask_graphics_198,x:485.3749,y:331.825}).wait(1).to({graphics:mask_graphics_199,x:485.3749,y:335.8251}).wait(75));

	// Fort
	this.instance_85 = new lib.CachedBmp_173();
	this.instance_85.setTransform(196.7,323.1,0.5,0.5);

	this.instance_86 = new lib.CachedBmp_172();
	this.instance_86.setTransform(373.1,322.55,0.5,0.5);

	this.instance_87 = new lib.CachedBmp_171();
	this.instance_87.setTransform(513.25,322.7,0.5,0.5);

	this.instance_88 = new lib.CachedBmp_170();
	this.instance_88.setTransform(671.5,322.7,0.5,0.5);

	var maskedShapeInstanceList = [this.instance_85,this.instance_86,this.instance_87,this.instance_88];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_88},{t:this.instance_87},{t:this.instance_86},{t:this.instance_85}]},193).wait(81));

	// M_Ilius (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_199 = new cjs.Graphics().p("EgqZAEBIAAoBMBUzAAAIAAIBg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(199).to({graphics:mask_1_graphics_199,x:485.923,y:380.8615}).wait(75));

	// Ilustraciones
	this.instance_89 = new lib.Ilustr("synched",0);
	this.instance_89.setTransform(483.15,320.55,1,1,0,0,0,264.1,24.1);
	this.instance_89._off = true;

	var maskedShapeInstanceList = [this.instance_89];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_89).wait(199).to({_off:false},0).to({y:378.95},10).wait(65));

	// Texto
	this.instance_90 = new lib.CachedBmp_174();
	this.instance_90.setTransform(474.1,423.8,0.5,0.5);

	this.instance_91 = new lib.CachedBmp_175();
	this.instance_91.setTransform(468.75,423.8,0.5,0.5);

	this.instance_92 = new lib.CachedBmp_176();
	this.instance_92.setTransform(465.05,423.8,0.5,0.5);

	this.instance_93 = new lib.CachedBmp_177();
	this.instance_93.setTransform(461.05,423.8,0.5,0.5);

	this.instance_94 = new lib.CachedBmp_178();
	this.instance_94.setTransform(453.6,423.8,0.5,0.5);

	this.instance_95 = new lib.CachedBmp_179();
	this.instance_95.setTransform(448.4,423.8,0.5,0.5);

	this.instance_96 = new lib.CachedBmp_180();
	this.instance_96.setTransform(444.5,423.8,0.5,0.5);

	this.instance_97 = new lib.CachedBmp_181();
	this.instance_97.setTransform(436.05,423.8,0.5,0.5);

	this.instance_98 = new lib.CachedBmp_182();
	this.instance_98.setTransform(430.45,423.8,0.5,0.5);

	this.instance_99 = new lib.CachedBmp_183();
	this.instance_99.setTransform(425,423.8,0.5,0.5);

	this.instance_100 = new lib.CachedBmp_184();
	this.instance_100.setTransform(416.5,423.8,0.5,0.5);

	this.instance_101 = new lib.CachedBmp_185();
	this.instance_101.setTransform(408.2,423.8,0.5,0.5);

	this.instance_102 = new lib.CachedBmp_186();
	this.instance_102.setTransform(403,423.8,0.5,0.5);

	this.instance_103 = new lib.CachedBmp_187();
	this.instance_103.setTransform(397.5,423.8,0.5,0.5);

	this.instance_104 = new lib.CachedBmp_188();
	this.instance_104.setTransform(392.05,423.8,0.5,0.5);

	this.instance_105 = new lib.CachedBmp_189();
	this.instance_105.setTransform(388.4,423.8,0.5,0.5);

	this.instance_106 = new lib.CachedBmp_190();
	this.instance_106.setTransform(383,423.8,0.5,0.5);

	this.instance_107 = new lib.CachedBmp_191();
	this.instance_107.setTransform(379.35,423.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_90}]},209).to({state:[{t:this.instance_91}]},2).to({state:[{t:this.instance_92}]},2).to({state:[{t:this.instance_93}]},2).to({state:[{t:this.instance_94}]},2).to({state:[{t:this.instance_95}]},2).to({state:[{t:this.instance_96}]},2).to({state:[{t:this.instance_97}]},2).to({state:[{t:this.instance_98}]},2).to({state:[{t:this.instance_99}]},2).to({state:[{t:this.instance_100}]},2).to({state:[{t:this.instance_101}]},2).to({state:[{t:this.instance_102}]},2).to({state:[{t:this.instance_103}]},2).to({state:[{t:this.instance_104}]},2).to({state:[{t:this.instance_105}]},2).to({state:[{t:this.instance_106}]},2).to({state:[{t:this.instance_107}]},2).wait(31));

	// M_Ai (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_244 = new cjs.Graphics().p("AkQEFIAAoJIIhAAIAAIJg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(244).to({graphics:mask_2_graphics_244,x:363.5523,y:493.0123}).wait(30));

	// Ai
	this.instance_108 = new lib.Ai("synched",0);
	this.instance_108.setTransform(307.1,492.9,1,1,0,0,0,24.8,24.8);
	this.instance_108._off = true;

	var maskedShapeInstanceList = [this.instance_108];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_108).wait(244).to({_off:false},0).to({x:363.1},5).wait(25));

	// M_Ps (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_250 = new cjs.Graphics().p("AkQEFIAAoJIIhAAIAAIJg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(250).to({graphics:mask_3_graphics_250,x:422.352,y:493.0123}).wait(24));

	// Ps
	this.instance_109 = new lib.Ps("synched",0);
	this.instance_109.setTransform(363.25,492.9);
	this.instance_109._off = true;

	var maskedShapeInstanceList = [this.instance_109];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_109).wait(250).to({_off:false},0).to({x:421.65},5).wait(19));

	// M_An (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_256 = new cjs.Graphics().p("AkQEFIAAoJIIhAAIAAIJg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(256).to({graphics:mask_4_graphics_256,x:480.7521,y:493.0123}).wait(18));

	// An
	this.instance_110 = new lib.An("synched",0);
	this.instance_110.setTransform(422.15,492.9,1,1,0,0,0,24.8,24.8);
	this.instance_110._off = true;

	var maskedShapeInstanceList = [this.instance_110];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_110).wait(256).to({_off:false},0).to({x:480.55},5).wait(13));

	// M_Pr (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_262 = new cjs.Graphics().p("AkQEFIAAoJIIhAAIAAIJg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(262).to({graphics:mask_5_graphics_262,x:538.7526,y:493.0123}).wait(12));

	// Pr
	this.instance_111 = new lib.Pr("synched",0);
	this.instance_111.setTransform(480.65,492.9,1,1,0,0,0,24.8,24.8);
	this.instance_111._off = true;

	var maskedShapeInstanceList = [this.instance_111];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_111).wait(262).to({_off:false},0).to({x:539.45},5).wait(7));

	// M_Id (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_268 = new cjs.Graphics().p("AkQEFIAAoJIIhAAIAAIJg");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:null,x:0,y:0}).wait(268).to({graphics:mask_6_graphics_268,x:596.7522,y:493.0123}).wait(6));

	// Id
	this.instance_112 = new lib.Id("synched",0);
	this.instance_112.setTransform(539.5,492.8,1,1,0,0,0,24.8,24.8);
	this.instance_112._off = true;

	var maskedShapeInstanceList = [this.instance_112];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_112).wait(268).to({_off:false},0).to({x:598.3},5).wait(1));

	// Boton_Atras
	this.Atras = new lib.Boton_Atras();
	this.Atras.name = "Atras";
	this.Atras.setTransform(100.65,542.95);
	new cjs.ButtonHelper(this.Atras, 0, 1, 2, false, new lib.Boton_Atras(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Atras).wait(274));

	// Boton_Cont
	this.Contenido = new lib.Boton_Contenido();
	this.Contenido.name = "Contenido";
	this.Contenido.setTransform(152.55,553.8,1,1,0,0,0,14.5,11);
	new cjs.ButtonHelper(this.Contenido, 0, 1, 2, false, new lib.Boton_Contenido(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Contenido).wait(274));

	// Boton_Sig
	this.Sig = new lib.Boton_Sig();
	this.Sig.name = "Sig";
	this.Sig.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.Sig, 0, 1, 2, false, new lib.Boton_Sig(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sig).wait(274));

	// Diseño
	this.instance_113 = new lib.Pantalla("synched",0);
	this.instance_113.setTransform(481.05,320.25,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_114 = new lib.Pantalla("synched",0);
	this.instance_114.setTransform(481.05,320.25,3.2917,3.2917,0,0,0,145.1,96.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#121212").s().p("EhK/AyFMAAAhkJMCV/AAAMAAABkJg");
	this.shape.setTransform(480.375,321.425);

	this.instance_115 = new lib.Pantalla("synched",0);
	this.instance_115.setTransform(479.7,315.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_116 = new lib.Pantalla("synched",0);
	this.instance_116.setTransform(480.2,315.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_117 = new lib.Pantalla("synched",0);
	this.instance_117.setTransform(480.2,315.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_118 = new lib.Pantalla("synched",0);
	this.instance_118.setTransform(479.7,315.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_118},{t:this.instance_117},{t:this.instance_116},{t:this.instance_115},{t:this.shape},{t:this.instance_114},{t:this.instance_113}]}).wait(274));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(480.4,321,480,320.9);
// library properties:
lib.properties = {
	id: '19421933841DD541AA065A2454441047',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/perfil_atlas_1.png?1655438845455", id:"perfil_atlas_1"},
		{src:"images/perfil_atlas_2.png?1655438845456", id:"perfil_atlas_2"},
		{src:"images/perfil_atlas_3.png?1655438845457", id:"perfil_atlas_3"},
		{src:"images/perfil_atlas_4.png?1655438845459", id:"perfil_atlas_4"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['19421933841DD541AA065A2454441047'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;