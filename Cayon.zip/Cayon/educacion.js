(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"educacion_atlas_1", frames: [[0,0,1921,1283]]},
		{name:"educacion_atlas_2", frames: [[0,0,1920,1282]]},
		{name:"educacion_atlas_3", frames: [[1721,233,171,76],[1972,88,74,76],[1938,301,104,76],[1840,457,120,57],[1962,457,68,76],[1938,379,96,76],[0,0,1719,1082],[842,1152,98,51],[1721,311,215,55],[842,1205,618,66],[1721,0,319,86],[1894,233,133,66],[1721,425,117,66],[0,1152,840,66],[1721,176,281,55],[1721,368,215,55],[0,1084,1226,66],[1721,88,249,86],[1228,1084,431,119]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_232 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_231 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_230 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_229 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_228 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_227 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_226 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_225 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_224 = function() {
	this.initialize(ss["educacion_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_223 = function() {
	this.initialize(ss["educacion_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_222 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_221 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_220 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_219 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_218 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_217 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_216 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_215 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_214 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_213 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_212 = function() {
	this.initialize(ss["educacion_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Vertical = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EgWpgqKMAtTAAAMAAABUVMgtTAAAg");
	this.shape.setTransform(43.86,81.6491,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,89.8,165.3);


(lib.Linea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#898989").s().p("AvmAPIAAgdIfNAAIAAAdg");
	this.shape.setTransform(106.1313,1.5,1.0623,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,212.3,3);


(lib.Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EhDLgODMCGXAAAIAAcHMiGXAAAg");
	this.shape.setTransform(130.0675,27.2142,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,262.2,56.5);


(lib.Carga4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape.setTransform(0.5,2.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1,4.1);


(lib.Carga3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgZAjIAAhFIAzAAIggBFg");
	this.shape.setTransform(2.6,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.9);


(lib.Carga2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgoAjIAihFIAvAAIgiBFg");
	this.shape.setTransform(4.075,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,8.2,6.9);


(lib.Carga1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgdAjIAhhFIAaAAIAABFg");
	this.shape.setTransform(2.975,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6,6.9);


(lib.Boton_Sig = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiPhsIEfBvIkfBqg");
	this.shape.setTransform(14.375,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiPhsIEfBvIkfBqg");
	this.shape_1.setTransform(14.375,10.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.9);


(lib.Boton_Contenido = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape.setTransform(14.475,10.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape_1.setTransform(14.475,10.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,29,22);


(lib.Boton_Atras = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape.setTransform(14.4,10.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape_1.setTransform(14.4,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.8);


(lib.Bateria = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_4
	this.instance = new lib.Carga1("synched",0);
	this.instance.setTransform(11.3,3.65,1,1,0,0,0,3,3.5);

	this.instance_1 = new lib.Carga2("synched",0);
	this.instance_1.setTransform(7.35,3.65,1,1,0,0,0,4,3.5);

	this.instance_2 = new lib.Carga3("synched",0);
	this.instance_2.setTransform(3.9,3.6,1,1,0,0,0,2.6,3.5);

	this.instance_3 = new lib.Carga4("synched",0);
	this.instance_3.setTransform(0.6,3.35,1,1,0,0,0,0.5,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance},{t:this.instance_1}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},10).wait(11));

	// Capa_1
	this.instance_4 = new lib.CachedBmp_225();
	this.instance_4.setTransform(-0.35,-0.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.3,14.9,7.7);


(lib.Pantalla = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Bateria();
	this.instance.setTransform(254.2,26.5,1,1,0,0,0,7,3.5);

	this.instance_1 = new lib.Horizontal("synched",0);
	this.instance_1.setTransform(144.95,96.5,1,1,0,0,0,130.1,27.2);
	this.instance_1.alpha = 0.0703;

	this.instance_2 = new lib.Vertical("synched",0);
	this.instance_2.setTransform(144.95,96.55,1,1,0,0,0,43.9,81.7);
	this.instance_2.alpha = 0.0703;

	this.instance_3 = new lib.CachedBmp_232();
	this.instance_3.setTransform(198.85,162.7,0.1519,0.1519);

	this.instance_4 = new lib.CachedBmp_231();
	this.instance_4.setTransform(166.75,162.5,0.1519,0.1519);

	this.instance_5 = new lib.CachedBmp_230();
	this.instance_5.setTransform(147.1,162.5,0.1519,0.1519);

	this.instance_6 = new lib.CachedBmp_229();
	this.instance_6.setTransform(146.6,164.25,0.1519,0.1519);

	this.instance_7 = new lib.CachedBmp_228();
	this.instance_7.setTransform(111.25,162.5,0.1519,0.1519);

	this.instance_8 = new lib.CachedBmp_227();
	this.instance_8.setTransform(76.55,162.5,0.1519,0.1519);

	this.instance_9 = new lib.CachedBmp_226();
	this.instance_9.setTransform(14.35,14.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,13.9,262.1,165.29999999999998);


// stage content:
(lib.educacion = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,44];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Atras.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('perfil.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Cont.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contenido.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Sig.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('identidad_visual.html', '_self');
		});
	}
	this.frame_44 = function() {
		var _this = this;
		/*
		Detener un clip de película o un vídeo
		Detiene el clip de película o el vídeo especificado.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(1));

	// M_Edu (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_16 = new cjs.Graphics().p("Ad+O3IAAgeMAhLAAAIAAAeg");
	var mask_graphics_17 = new cjs.Graphics().p("Ad+O3IAAg/MAhLAAAIAAA/g");
	var mask_graphics_18 = new cjs.Graphics().p("Ad+O3IAAhhMAhLAAAIAABhg");
	var mask_graphics_19 = new cjs.Graphics().p("Ad+O3IAAiCMAhLAAAIAACCg");
	var mask_graphics_20 = new cjs.Graphics().p("Ad+O3IAAikMAhLAAAIAACkg");
	var mask_graphics_21 = new cjs.Graphics().p("Ad+O3IAAjGMAhLAAAIAADGg");
	var mask_graphics_22 = new cjs.Graphics().p("Ad+O3IAAjnMAhLAAAIAADng");
	var mask_graphics_23 = new cjs.Graphics().p("Ad+O3IAAkJMAhLAAAIAAEJg");
	var mask_graphics_24 = new cjs.Graphics().p("Ad+O3IAAkqMAhLAAAIAAEqg");
	var mask_graphics_25 = new cjs.Graphics().p("Ad+O3IAAlMMAhLAAAIAAFMg");
	var mask_graphics_26 = new cjs.Graphics().p("Ad+O3IAAltMAhLAAAIAAFtg");
	var mask_graphics_27 = new cjs.Graphics().p("Ad+O3IAAmPMAhLAAAIAAGPg");
	var mask_graphics_28 = new cjs.Graphics().p("Ad+O3IAAmxMAhLAAAIAAGxg");
	var mask_graphics_29 = new cjs.Graphics().p("Ad+O3IAAnSMAhLAAAIAAHSg");
	var mask_graphics_30 = new cjs.Graphics().p("Ad+O3IAAn0MAhLAAAIAAH0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_graphics_16,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_17,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_18,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_19,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_20,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_21,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_22,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_23,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_24,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_25,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_26,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_27,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_28,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_29,x:404.0753,y:95.125}).wait(1).to({graphics:mask_graphics_30,x:404.0753,y:95.125}).wait(15));

	// Educación
	this.instance = new lib.CachedBmp_212();
	this.instance.setTransform(594.55,132.8,0.5,0.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).wait(29));

	// Linea
	this.instance_1 = new lib.Linea("synched",0);
	this.instance_1.setTransform(699.05,188.85,0.0448,1,0,0,0,106.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:106.1,regY:1.5,scaleX:1,x:702,y:188.75},16).wait(29));

	// M_Sec (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_30 = new cjs.Graphics().p("EgmcAR1IAAgeMBnyAAAIAAAeg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EgmcATbIAAjqMBnyAAAIAADqg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EgmbAVAIAAm1MBnyAAAIAAG1g");
	var mask_1_graphics_33 = new cjs.Graphics().p("EgmbAWlIAAqAMBnyAAAIAAKAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EgmaAYKIAAtKMBnyAAAIAANKg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EgmZAZwIAAwWMBnxAAAIAAQWg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EgmZAbVIAAzhMBnyAAAIAAThg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EgmYAc6IAA2sMBnxAAAIAAWsg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EgmYAefIAA53MBnyAAAIAAZ3g");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgmXAgFIAA9DMBnyAAAIAAdDg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EgmXAhqMAAAggOMBnyAAAMAAAAgOg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgmWAjPMAAAgjYMBnyAAAMAAAAjYg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgmWAk1MAAAgmkMBnyAAAMAAAAmkg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgmVAmaMAAAgpvMBnyAAAMAAAApvg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgmcAn/MAAAgs6MBnyAAAMAAAAs6g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(30).to({graphics:mask_1_graphics_30,x:418.1581,y:114.125}).wait(1).to({graphics:mask_1_graphics_31,x:418.214,y:124.2523}).wait(1).to({graphics:mask_1_graphics_32,x:418.2699,y:134.3795}).wait(1).to({graphics:mask_1_graphics_33,x:418.3258,y:144.5068}).wait(1).to({graphics:mask_1_graphics_34,x:418.3817,y:154.634}).wait(1).to({graphics:mask_1_graphics_35,x:418.4376,y:164.7613}).wait(1).to({graphics:mask_1_graphics_36,x:418.4935,y:174.8885}).wait(1).to({graphics:mask_1_graphics_37,x:418.5494,y:185.0158}).wait(1).to({graphics:mask_1_graphics_38,x:418.6053,y:195.143}).wait(1).to({graphics:mask_1_graphics_39,x:418.6612,y:205.2703}).wait(1).to({graphics:mask_1_graphics_40,x:418.7171,y:215.3975}).wait(1).to({graphics:mask_1_graphics_41,x:418.7729,y:225.5248}).wait(1).to({graphics:mask_1_graphics_42,x:418.8288,y:235.652}).wait(1).to({graphics:mask_1_graphics_43,x:418.8847,y:245.7793}).wait(1).to({graphics:mask_1_graphics_44,x:418.1581,y:255.9065}).wait(1));

	// Texto
	this.instance_2 = new lib.CachedBmp_222();
	this.instance_2.setTransform(703.35,284.8,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_221();
	this.instance_3.setTransform(501.5,258.4,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_220();
	this.instance_4.setTransform(650.9,221.2,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_219();
	this.instance_5.setTransform(744.15,465.6,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_218();
	this.instance_6.setTransform(752.05,380.2,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_217();
	this.instance_7.setTransform(390.8,439.7,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_216();
	this.instance_8.setTransform(669.8,488.65,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_215();
	this.instance_9.setTransform(704.15,405.35,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_214();
	this.instance_10.setTransform(197.7,354.8,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_213();
	this.instance_11.setTransform(685.9,317.55,0.5,0.5);

	var maskedShapeInstanceList = [this.instance_2,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.instance_7,this.instance_8,this.instance_9,this.instance_10,this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]},30).wait(15));

	// Boton_Atras
	this.Atras = new lib.Boton_Atras();
	this.Atras.name = "Atras";
	this.Atras.setTransform(100.65,542.95);
	new cjs.ButtonHelper(this.Atras, 0, 1, 2, false, new lib.Boton_Atras(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Atras).wait(45));

	// Boton_Cont
	this.Cont = new lib.Boton_Contenido();
	this.Cont.name = "Cont";
	this.Cont.setTransform(152.55,553.8,1,1,0,0,0,14.5,11);
	new cjs.ButtonHelper(this.Cont, 0, 1, 2, false, new lib.Boton_Contenido(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Cont).wait(45));

	// Boton_Sig
	this.Sig = new lib.Boton_Sig();
	this.Sig.name = "Sig";
	this.Sig.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.Sig, 0, 1, 2, false, new lib.Boton_Sig(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sig).wait(45));

	// Diseño
	this.instance_12 = new lib.Pantalla("synched",0);
	this.instance_12.setTransform(480.65,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_13 = new lib.Pantalla("synched",0);
	this.instance_13.setTransform(480.65,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_14 = new lib.CachedBmp_224();
	this.instance_14.setTransform(0,0,0.5,0.5);

	this.instance_15 = new lib.Pantalla("synched",0);
	this.instance_15.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_16 = new lib.Pantalla("synched",0);
	this.instance_16.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_17 = new lib.Pantalla("synched",0);
	this.instance_17.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_18 = new lib.Pantalla("synched",0);
	this.instance_18.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_19 = new lib.CachedBmp_223();
	this.instance_19.setTransform(0.25,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12}]}).wait(45));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(480,320,480.79999999999995,321.5);
// library properties:
lib.properties = {
	id: '41E4EB8FB2DC4E4DA17886A66A965290',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/educacion_atlas_1.png?1655438893049", id:"educacion_atlas_1"},
		{src:"images/educacion_atlas_2.png?1655438893049", id:"educacion_atlas_2"},
		{src:"images/educacion_atlas_3.png?1655438893049", id:"educacion_atlas_3"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['41E4EB8FB2DC4E4DA17886A66A965290'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;