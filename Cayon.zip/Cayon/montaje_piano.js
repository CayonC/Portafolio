(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"montaje_piano_atlas_1", frames: [[391,1084,171,76],[391,1162,74,76],[564,1084,104,76],[768,1084,120,57],[0,1165,68,76],[670,1084,96,76],[0,0,1719,1082],[70,1218,54,62],[890,1084,79,79],[70,1165,98,51],[0,1084,389,79]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_498 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_497 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_496 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_495 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_494 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_493 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_492 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_491 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_490 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_489 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_488 = function() {
	this.initialize(ss["montaje_piano_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.MockupPiano = function() {
	this.initialize(img.MockupPiano);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2500,2000);


(lib.Vertical = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EgWpgqKMAtTAAAMAAABUVMgtTAAAg");
	this.shape.setTransform(43.86,81.6491,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,89.8,165.3);


(lib.Linea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#898989").s().p("AvmAPIAAgdIfNAAIAAAdg");
	this.shape.setTransform(106.1313,1.5,1.0623,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,212.3,3);


(lib.Imagen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.MockupPiano();
	this.instance.setTransform(0,0,0.3123,0.3123);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,780.7,624.5);


(lib.Iconos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_491();
	this.instance.setTransform(50.45,3.6,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_490();
	this.instance_1.setTransform(43.95,-1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,-1,39.5,39.5);


(lib.Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EhDLgODMCGXAAAIAAcHMiGXAAAg");
	this.shape.setTransform(130.0675,27.2142,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,262.2,56.5);


(lib.Carga4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape.setTransform(0.5,2.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1,4.1);


(lib.Carga3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgZAjIAAhFIAzAAIggBFg");
	this.shape.setTransform(2.6,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.9);


(lib.Carga2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgoAjIAihFIAvAAIgiBFg");
	this.shape.setTransform(4.075,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,8.2,6.9);


(lib.Carga1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgdAjIAhhFIAaAAIAABFg");
	this.shape.setTransform(2.975,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6,6.9);


(lib.Boton_Sig = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiPhsIEfBvIkfBqg");
	this.shape.setTransform(14.375,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiPhsIEfBvIkfBqg");
	this.shape_1.setTransform(14.375,10.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.9);


(lib.Boton_Contenido = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape.setTransform(14.475,10.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape_1.setTransform(14.475,10.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,29,22);


(lib.Boton_Atras = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape.setTransform(14.4,10.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape_1.setTransform(14.4,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.8);


(lib.Bateria = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_4
	this.instance = new lib.Carga1("synched",0);
	this.instance.setTransform(11.3,3.65,1,1,0,0,0,3,3.5);

	this.instance_1 = new lib.Carga2("synched",0);
	this.instance_1.setTransform(7.35,3.65,1,1,0,0,0,4,3.5);

	this.instance_2 = new lib.Carga3("synched",0);
	this.instance_2.setTransform(3.9,3.6,1,1,0,0,0,2.6,3.5);

	this.instance_3 = new lib.Carga4("synched",0);
	this.instance_3.setTransform(0.6,3.35,1,1,0,0,0,0.5,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance},{t:this.instance_1}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},10).wait(11));

	// Capa_1
	this.instance_4 = new lib.CachedBmp_489();
	this.instance_4.setTransform(-0.35,-0.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.3,14.9,7.7);


(lib.Pantalla = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Bateria();
	this.instance.setTransform(254.2,26.5,1,1,0,0,0,7,3.5);

	this.instance_1 = new lib.Horizontal("synched",0);
	this.instance_1.setTransform(144.95,96.5,1,1,0,0,0,130.1,27.2);
	this.instance_1.alpha = 0.0703;

	this.instance_2 = new lib.Vertical("synched",0);
	this.instance_2.setTransform(144.95,96.55,1,1,0,0,0,43.9,81.7);
	this.instance_2.alpha = 0.0703;

	this.instance_3 = new lib.CachedBmp_498();
	this.instance_3.setTransform(198.85,162.7,0.1519,0.1519);

	this.instance_4 = new lib.CachedBmp_497();
	this.instance_4.setTransform(166.75,162.5,0.1519,0.1519);

	this.instance_5 = new lib.CachedBmp_496();
	this.instance_5.setTransform(147.1,162.5,0.1519,0.1519);

	this.instance_6 = new lib.CachedBmp_495();
	this.instance_6.setTransform(146.6,164.25,0.1519,0.1519);

	this.instance_7 = new lib.CachedBmp_494();
	this.instance_7.setTransform(111.25,162.5,0.1519,0.1519);

	this.instance_8 = new lib.CachedBmp_493();
	this.instance_8.setTransform(76.55,162.5,0.1519,0.1519);

	this.instance_9 = new lib.CachedBmp_492();
	this.instance_9.setTransform(14.35,14.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,13.9,262.1,165.29999999999998);


// stage content:
(lib.montaje_piano = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,36];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Atras.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('Montaje_Pez.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Contenido.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contenido.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Sig.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('Contacto.html', '_self');
		});
	}
	this.frame_36 = function() {
		var _this = this;
		/*
		Detener un clip de película o un vídeo
		Detiene el clip de película o el vídeo especificado.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(36).call(this.frame_36).wait(1));

	// Borde_Negro
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("EhLAgyKMCWBAAAMAAABkVMiWBAAAgEhC7gqrMCF3AAAMAAABUlMiF3AAAg");
	this.shape.setTransform(480.15,321.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#121212").s().p("EhLAAyLMAAAhkVMCWBAAAMAAABkVgEhC7Ap6MCF2AAAMAAAhUlMiF2AAAg");
	this.shape_1.setTransform(480.15,321.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(37));

	// M_Text (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgQkApBIAAn0MAhJAAAIAAH0g");
	var mask_graphics_15 = new cjs.Graphics().p("EgQzApDIAAn3MAhnAAAIAAH3g");
	var mask_graphics_16 = new cjs.Graphics().p("EgRCApFIAAn6MAiFAAAIAAH6g");
	var mask_graphics_17 = new cjs.Graphics().p("EgRRApHIAAn9MAijAAAIAAH9g");
	var mask_graphics_18 = new cjs.Graphics().p("EgRgApJIAAoAMAjBAAAIAAIAg");
	var mask_graphics_19 = new cjs.Graphics().p("EgRvApMIAAoEMAjfAAAIAAIEg");
	var mask_graphics_20 = new cjs.Graphics().p("EgR+ApOIAAoHMAj9AAAIAAIHg");
	var mask_graphics_21 = new cjs.Graphics().p("EgSNApQIAAoJMAkbAAAIAAIJg");
	var mask_graphics_22 = new cjs.Graphics().p("EgScApSIAAoMMAk5AAAIAAIMg");
	var mask_graphics_23 = new cjs.Graphics().p("EgSrApUIAAoPMAlXAAAIAAIPg");
	var mask_graphics_24 = new cjs.Graphics().p("EgS5ApWIAAoSMAlzAAAIAAISg");
	var mask_graphics_25 = new cjs.Graphics().p("EgTIApYIAAoVMAmRAAAIAAIVg");
	var mask_graphics_26 = new cjs.Graphics().p("EgSqApaIAAoYMAmwAAAIAAIYg");
	var mask_graphics_27 = new cjs.Graphics().p("EgSHApcIAAobMAnOAAAIAAIbg");
	var mask_graphics_28 = new cjs.Graphics().p("EgRjApeIAAoeMAnrAAAIAAIeg");
	var mask_graphics_29 = new cjs.Graphics().p("EgRAAphIAAoiMAoJAAAIAAIig");
	var mask_graphics_30 = new cjs.Graphics().p("EgQdApjIAAolMAonAAAIAAIlg");
	var mask_graphics_31 = new cjs.Graphics().p("EgP6AplIAAooMApFAAAIAAIog");
	var mask_graphics_32 = new cjs.Graphics().p("EgPXApnIAAorMApjAAAIAAIrg");
	var mask_graphics_33 = new cjs.Graphics().p("EgO0AppIAAouMAqBAAAIAAIug");
	var mask_graphics_34 = new cjs.Graphics().p("EgORAprIAAoxMAqfAAAIAAIxg");
	var mask_graphics_35 = new cjs.Graphics().p("EgNtAptIAAozMAq8AAAIAAIzg");
	var mask_graphics_36 = new cjs.Graphics().p("EgNLAphIAAo3MAraAAAIAAI3g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:-4.9187,y:262.5}).wait(1).to({graphics:mask_graphics_15,x:6.5873,y:262.7102}).wait(1).to({graphics:mask_graphics_16,x:18.0934,y:262.9203}).wait(1).to({graphics:mask_graphics_17,x:29.5995,y:263.1305}).wait(1).to({graphics:mask_graphics_18,x:41.1056,y:263.3407}).wait(1).to({graphics:mask_graphics_19,x:52.6116,y:263.5508}).wait(1).to({graphics:mask_graphics_20,x:64.1177,y:263.761}).wait(1).to({graphics:mask_graphics_21,x:75.6238,y:263.9711}).wait(1).to({graphics:mask_graphics_22,x:87.1299,y:264.1813}).wait(1).to({graphics:mask_graphics_23,x:98.6359,y:264.3915}).wait(1).to({graphics:mask_graphics_24,x:110.142,y:264.6016}).wait(1).to({graphics:mask_graphics_25,x:121.6481,y:264.8118}).wait(1).to({graphics:mask_graphics_26,x:128.5914,y:265.022}).wait(1).to({graphics:mask_graphics_27,x:135.0906,y:265.2321}).wait(1).to({graphics:mask_graphics_28,x:141.5899,y:265.4423}).wait(1).to({graphics:mask_graphics_29,x:148.0891,y:265.6524}).wait(1).to({graphics:mask_graphics_30,x:154.5884,y:265.8626}).wait(1).to({graphics:mask_graphics_31,x:161.0877,y:266.0728}).wait(1).to({graphics:mask_graphics_32,x:167.5869,y:266.2829}).wait(1).to({graphics:mask_graphics_33,x:174.0862,y:266.4931}).wait(1).to({graphics:mask_graphics_34,x:180.5854,y:266.7033}).wait(1).to({graphics:mask_graphics_35,x:187.0847,y:266.9134}).wait(1).to({graphics:mask_graphics_36,x:193.4857,y:265.707}).wait(1));

	// Texto
	this.instance = new lib.CachedBmp_488();
	this.instance.setTransform(109.2,481.8,0.5,0.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).wait(23));

	// M_Icon (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_14 = new cjs.Graphics().p("AnVD1IAAnpIOrAAIAAHpg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_1_graphics_14,x:816,y:507.4}).wait(23));

	// Iconos
	this.instance_1 = new lib.Iconos("synched",0);
	this.instance_1.setTransform(907.45,507.4,1,1,0,0,0,41.3,18.8);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:820.45},16).wait(7));

	// Linea
	this.instance_2 = new lib.Linea("synched",0);
	this.instance_2.setTransform(103.1,505.05,0.0164,1,-89.9423,0,0,106.5,1.7);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(9).to({_off:false},0).to({regX:105.6,regY:1.6,scaleX:0.187,x:103,y:502.1},6).wait(22));

	// Diseño
	this.instance_3 = new lib.Pantalla("synched",0);
	this.instance_3.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_4 = new lib.Pantalla("synched",0);
	this.instance_4.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_5 = new lib.Pantalla("synched",0);
	this.instance_5.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_6 = new lib.Pantalla("synched",0);
	this.instance_6.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(37));

	// Boton_Atras
	this.Atras = new lib.Boton_Atras();
	this.Atras.name = "Atras";
	this.Atras.setTransform(100.65,542.95);
	new cjs.ButtonHelper(this.Atras, 0, 1, 2, false, new lib.Boton_Atras(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Atras).wait(37));

	// Boton_Cont
	this.Contenido = new lib.Boton_Contenido();
	this.Contenido.name = "Contenido";
	this.Contenido.setTransform(152.55,553.8,1,1,0,0,0,14.5,11);
	new cjs.ButtonHelper(this.Contenido, 0, 1, 2, false, new lib.Boton_Contenido(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Contenido).wait(37));

	// Boton_Sig
	this.Sig = new lib.Boton_Sig();
	this.Sig.name = "Sig";
	this.Sig.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.Sig, 0, 1, 2, false, new lib.Boton_Sig(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sig).wait(37));

	// Gris
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#333333").ss(1,1,1).p("EhDwgqhMCHiAAAMAAABVDMiHiAAAg");
	this.shape_2.setTransform(481.8,316.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#121212").s().p("EhDwAqiMAAAhVCMCHiAAAMAAABVCg");
	this.shape_3.setTransform(481.8,316.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[]},1).wait(36));

	// Imagen
	this.instance_7 = new lib.Imagen("synched",0);
	this.instance_7.setTransform(482.3,298.2,1,1,0,0,0,390.3,312.2);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({alpha:1},14).wait(23));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(479.1,306,482.19999999999993,337.29999999999995);
// library properties:
lib.properties = {
	id: 'A7B9E1DE34AE9C468571C1F532CD0EF5',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/MockupPiano.jpg?1655440826462", id:"MockupPiano"},
		{src:"images/montaje_piano_atlas_1.png?1655440826339", id:"montaje_piano_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A7B9E1DE34AE9C468571C1F532CD0EF5'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;