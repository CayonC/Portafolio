(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"contenido_atlas_1", frames: [[1500,1436,365,69],[1600,1260,372,86],[391,1263,372,86],[0,1293,372,86],[765,1348,372,86],[1834,1130,170,70],[2020,1296,28,86],[102,1469,28,86],[2013,954,32,86],[2016,1208,32,86],[2006,1120,40,86],[1984,442,47,86],[132,1469,28,86],[162,1469,28,86],[630,1439,32,86],[664,1439,32,86],[1974,1208,40,86],[1984,530,47,86],[192,1469,28,86],[222,1469,28,86],[698,1439,32,86],[0,1469,32,86],[1981,1419,40,86],[1984,618,47,86],[252,1469,28,86],[282,1469,28,86],[34,1469,32,86],[68,1469,32,86],[588,1439,40,86],[1984,706,47,86],[1721,866,171,76],[818,1175,74,76],[1875,1419,104,76],[466,1439,120,57],[1980,1042,68,76],[368,1439,96,76],[0,0,1719,1082],[1875,1348,143,69],[1894,866,144,86],[1721,944,144,86],[1867,954,144,86],[1834,1042,144,86],[1139,1348,366,86],[1507,1348,366,86],[374,1351,366,86],[0,1381,366,86],[742,1436,366,86],[427,1084,477,89],[906,1084,467,86],[1375,1084,457,86],[906,1172,457,86],[1365,1172,457,86],[0,1084,425,119],[1110,1436,388,69],[427,1175,389,86],[0,1205,389,86],[818,1260,389,86],[1209,1260,389,86],[1721,0,313,88],[1721,90,304,86],[1721,178,304,86],[1721,266,304,86],[1721,354,304,86],[1721,794,261,70],[1721,442,261,86],[1721,530,261,86],[1721,618,261,86],[1984,794,28,21],[1721,706,261,86],[1824,1202,98,51]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_85 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_77 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_75 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_73 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_69 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_68 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_67 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_66 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_62 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_61 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_52 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["contenido_atlas_1"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.Vertical = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EgWpgqKMAtTAAAMAAABUVMgtTAAAg");
	this.shape.setTransform(43.86,81.6491,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,89.8,165.3);


(lib.Social_media = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_79();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_81();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_82();
	this.instance_2.setTransform(-14.1,18.7,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_83();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_85();
	this.instance_4.setTransform(3.2,8.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_84();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).to({state:[{t:this.instance_2},{t:this.instance_3}]},1).to({state:[{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,200.1,43);


(lib.Siguiente = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiPhsIEfBvIkfBqg");
	this.shape.setTransform(14.375,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiPhsIEfBvIkfBqg");
	this.shape_1.setTransform(14.375,10.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.9);


(lib.Perfil = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_57();
	this.instance.setTransform(68,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_56();
	this.instance_1.setTransform(58.3,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_55();
	this.instance_2.setTransform(46.65,0,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_54();
	this.instance_3.setTransform(35,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_53();
	this.instance_4.setTransform(19.45,0,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_52();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_64();
	this.instance_6.setTransform(68,0,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_63();
	this.instance_7.setTransform(58.3,0,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_62();
	this.instance_8.setTransform(46.65,0,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_61();
	this.instance_9.setTransform(35,0,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_60();
	this.instance_10.setTransform(19.45,0,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_59();
	this.instance_11.setTransform(0,0,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_82();
	this.instance_12.setTransform(-14.1,16.15,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_71();
	this.instance_13.setTransform(68,0,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_70();
	this.instance_14.setTransform(58.3,0,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_69();
	this.instance_15.setTransform(46.65,0,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_68();
	this.instance_16.setTransform(35,0,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_67();
	this.instance_17.setTransform(19.45,0,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_66();
	this.instance_18.setTransform(0,0,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_78();
	this.instance_19.setTransform(0,3.85,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_77();
	this.instance_20.setTransform(68,0,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_76();
	this.instance_21.setTransform(58.3,0,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_75();
	this.instance_22.setTransform(46.65,0,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_74();
	this.instance_23.setTransform(35,0,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_73();
	this.instance_24.setTransform(19.45,0,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_72();
	this.instance_25.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]},1).to({state:[{t:this.instance_12},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13}]},1).to({state:[{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,99.1,43);


(lib.Linea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#898989").s().p("AvmAPIAAgdIfNAAIAAAdg");
	this.shape.setTransform(106.1313,1.5,1.0623,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,212.3,3);


(lib.Intro = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_38();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_40();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_82();
	this.instance_2.setTransform(-14.1,18.7,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_42();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_44();
	this.instance_4.setTransform(0.85,8.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_43();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).to({state:[{t:this.instance_2},{t:this.instance_3}]},1).to({state:[{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,86.5,43);


(lib.Ilustraciones = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_31();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_33();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_82();
	this.instance_2.setTransform(-14.1,17.9,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_35();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_37();
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_36();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).to({state:[{t:this.instance_2},{t:this.instance_3}]},1).to({state:[{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,197.1,43);


(lib.Identidad_visual = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_24();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_26();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_82();
	this.instance_2.setTransform(-14.1,16.75,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_28();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_30();
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_29();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).to({state:[{t:this.instance_2},{t:this.instance_3}]},1).to({state:[{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,252.6,44.5);


(lib.Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EhDLgODMCGXAAAIAAcHMiGXAAAg");
	this.shape.setTransform(130.0675,27.2142,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,262.2,56.5);


(lib.GContenido = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_23();
	this.instance.setTransform(-106.25,-29.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.2,-29.6,212.5,59.5);


(lib.Fotomontajes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_16();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_18();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_82();
	this.instance_2.setTransform(-14.1,16.35,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_20();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_22();
	this.instance_4.setTransform(0.8,8.05,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_21();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).to({state:[{t:this.instance_2},{t:this.instance_3}]},1).to({state:[{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,208.9,43);


(lib.Educacion = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_9();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_11();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_82();
	this.instance_2.setTransform(-14.1,15.45,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_13();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_15();
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_14();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).to({state:[{t:this.instance_2},{t:this.instance_3}]},1).to({state:[{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,170.6,44);


(lib.Contacto = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.CachedBmp_2();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_4();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_82();
	this.instance_2.setTransform(-14.1,17.9,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_6();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_8();
	this.instance_4.setTransform(0,8,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_7();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},1).to({state:[{t:this.instance_2},{t:this.instance_3}]},1).to({state:[{t:this.instance_5},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,0,144.6,43);


(lib.Carga4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape.setTransform(0.5,2.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1,4.1);


(lib.Carga3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgZAjIAAhFIAzAAIggBFg");
	this.shape.setTransform(2.6,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.9);


(lib.Carga2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgoAjIAihFIAvAAIgiBFg");
	this.shape.setTransform(4.075,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,8.2,6.9);


(lib.Carga1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgdAjIAhhFIAaAAIAABFg");
	this.shape.setTransform(2.975,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6,6.9);


(lib.Atras = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape.setTransform(14.4,10.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape_1.setTransform(14.4,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.8);


(lib.Bateria = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_4
	this.instance = new lib.Carga1("synched",0);
	this.instance.setTransform(11.3,3.65,1,1,0,0,0,3,3.5);

	this.instance_1 = new lib.Carga2("synched",0);
	this.instance_1.setTransform(7.35,3.65,1,1,0,0,0,4,3.5);

	this.instance_2 = new lib.Carga3("synched",0);
	this.instance_2.setTransform(3.9,3.6,1,1,0,0,0,2.6,3.5);

	this.instance_3 = new lib.Carga4("synched",0);
	this.instance_3.setTransform(0.6,3.35,1,1,0,0,0,0.5,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance},{t:this.instance_1}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},10).wait(11));

	// Capa_1
	this.instance_4 = new lib.CachedBmp_1();
	this.instance_4.setTransform(-0.35,-0.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.3,14.9,7.7);


(lib.Pantalla = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Bateria();
	this.instance.setTransform(254.2,26.5,1,1,0,0,0,7,3.5);

	this.instance_1 = new lib.Horizontal("synched",0);
	this.instance_1.setTransform(144.95,96.5,1,1,0,0,0,130.1,27.2);
	this.instance_1.alpha = 0.0703;

	this.instance_2 = new lib.Vertical("synched",0);
	this.instance_2.setTransform(144.95,96.55,1,1,0,0,0,43.9,81.7);
	this.instance_2.alpha = 0.0703;

	this.instance_3 = new lib.CachedBmp_51();
	this.instance_3.setTransform(198.85,162.7,0.1519,0.1519);

	this.instance_4 = new lib.CachedBmp_50();
	this.instance_4.setTransform(166.75,162.5,0.1519,0.1519);

	this.instance_5 = new lib.CachedBmp_49();
	this.instance_5.setTransform(147.1,162.5,0.1519,0.1519);

	this.instance_6 = new lib.CachedBmp_48();
	this.instance_6.setTransform(146.6,164.25,0.1519,0.1519);

	this.instance_7 = new lib.CachedBmp_47();
	this.instance_7.setTransform(111.25,162.5,0.1519,0.1519);

	this.instance_8 = new lib.CachedBmp_46();
	this.instance_8.setTransform(76.55,162.5,0.1519,0.1519);

	this.instance_9 = new lib.CachedBmp_45();
	this.instance_9.setTransform(14.35,14.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,13.9,262.1,165.29999999999998);


// stage content:
(lib.contenido = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,30,44,58,72,86,100,114,128,142];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Atras.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('index.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Siguiente.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('perfil.html', '_self');
		});
	}
	this.frame_30 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Perfil.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('perfil.html', '_self');
		});
	}
	this.frame_44 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Educ.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('educacion.html', '_self');
		});
	}
	this.frame_58 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Ident.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('identidad_visual.html', '_self');
		});
	}
	this.frame_72 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Intro.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('index.html', '_self');
		});
	}
	this.frame_86 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Cont.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contacto.html', '_self');
		});
	}
	this.frame_100 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Ilust.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('ilustraciones.html', '_self');
		});
	}
	this.frame_114 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Soc.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('social_media.html', '_self');
		});
	}
	this.frame_128 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Fot.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('fotomontajes.html', '_self');
		});
	}
	this.frame_142 = function() {
		var _this = this;
		/*
		Detener un clip de película o un vídeo
		Detiene el clip de película o el vídeo especificado.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30).call(this.frame_30).wait(14).call(this.frame_44).wait(14).call(this.frame_58).wait(14).call(this.frame_72).wait(14).call(this.frame_86).wait(14).call(this.frame_100).wait(14).call(this.frame_114).wait(14).call(this.frame_128).wait(14).call(this.frame_142).wait(1));

	// M_Fotom (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_128 = new cjs.Graphics().p("EAdwAlGIAAlSMAh0AAAIAAFSg");
	var mask_graphics_129 = new cjs.Graphics().p("EAdwAk6IAAlSMAh0AAAIAAFSg");
	var mask_graphics_130 = new cjs.Graphics().p("EAdwAkuIAAlSMAh0AAAIAAFSg");
	var mask_graphics_131 = new cjs.Graphics().p("EAdwAkiIAAlSMAh0AAAIAAFSg");
	var mask_graphics_132 = new cjs.Graphics().p("EAdwAkVIAAlSMAh0AAAIAAFSg");
	var mask_graphics_133 = new cjs.Graphics().p("EAdwAkJIAAlSMAh0AAAIAAFSg");
	var mask_graphics_134 = new cjs.Graphics().p("EAdwAj9IAAlSMAh0AAAIAAFSg");
	var mask_graphics_135 = new cjs.Graphics().p("EAdwAjxIAAlSMAh0AAAIAAFSg");
	var mask_graphics_136 = new cjs.Graphics().p("EAdwAjlIAAlSMAh0AAAIAAFSg");
	var mask_graphics_137 = new cjs.Graphics().p("EAdwAjZIAAlSMAh0AAAIAAFSg");
	var mask_graphics_138 = new cjs.Graphics().p("EAdwAjNIAAlSMAh0AAAIAAFSg");
	var mask_graphics_139 = new cjs.Graphics().p("EAdwAjAIAAlSMAh0AAAIAAFSg");
	var mask_graphics_140 = new cjs.Graphics().p("EAdwAi0IAAlSMAh0AAAIAAFSg");
	var mask_graphics_141 = new cjs.Graphics().p("EAdwAioIAAlSMAh0AAAIAAFSg");
	var mask_graphics_142 = new cjs.Graphics().p("EAdwAicIAAlSMAh0AAAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(128).to({graphics:mask_graphics_128,x:406.8423,y:237.4}).wait(1).to({graphics:mask_graphics_129,x:406.8423,y:236.1857}).wait(1).to({graphics:mask_graphics_130,x:406.8423,y:234.9714}).wait(1).to({graphics:mask_graphics_131,x:406.8423,y:233.7571}).wait(1).to({graphics:mask_graphics_132,x:406.8423,y:232.5429}).wait(1).to({graphics:mask_graphics_133,x:406.8423,y:231.3286}).wait(1).to({graphics:mask_graphics_134,x:406.8423,y:230.1143}).wait(1).to({graphics:mask_graphics_135,x:406.8423,y:228.9}).wait(1).to({graphics:mask_graphics_136,x:406.8423,y:227.6857}).wait(1).to({graphics:mask_graphics_137,x:406.8423,y:226.4714}).wait(1).to({graphics:mask_graphics_138,x:406.8423,y:225.2571}).wait(1).to({graphics:mask_graphics_139,x:406.8423,y:224.0429}).wait(1).to({graphics:mask_graphics_140,x:406.8423,y:222.8286}).wait(1).to({graphics:mask_graphics_141,x:406.8423,y:221.6143}).wait(1).to({graphics:mask_graphics_142,x:406.8423,y:220.4}).wait(1));

	// B_Fotom
	this.Fot = new lib.Fotomontajes();
	this.Fot.name = "Fot";
	this.Fot.setTransform(712.2,419.75,1,1,0,0,0,97.3,21.4);
	this.Fot._off = true;
	new cjs.ButtonHelper(this.Fot, 0, 1, 2, false, new lib.Fotomontajes(), 3);

	var maskedShapeInstanceList = [this.Fot];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Fot).wait(128).to({_off:false},0).wait(15));

	// M_Social (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_114 = new cjs.Graphics().p("Ae3d7IAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_115 = new cjs.Graphics().p("Ae3dxIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_116 = new cjs.Graphics().p("Ae3dnIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_117 = new cjs.Graphics().p("Ae3dcIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_118 = new cjs.Graphics().p("Ae3dSIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_119 = new cjs.Graphics().p("Ae3dHIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_120 = new cjs.Graphics().p("Ae3c9IAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_121 = new cjs.Graphics().p("Ae3czIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_122 = new cjs.Graphics().p("Ae3coIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_123 = new cjs.Graphics().p("Ae3ceIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_124 = new cjs.Graphics().p("Ae3cUIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_125 = new cjs.Graphics().p("Ae3cJIAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_126 = new cjs.Graphics().p("Ae3b/IAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_127 = new cjs.Graphics().p("Ae3b1IAAlSMAgeAAAIAAFSg");
	var mask_1_graphics_128 = new cjs.Graphics().p("Ae3bqIAAlSMAgeAAAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(114).to({graphics:mask_1_graphics_114,x:405.2914,y:191.525}).wait(1).to({graphics:mask_1_graphics_115,x:405.2914,y:190.4893}).wait(1).to({graphics:mask_1_graphics_116,x:405.2914,y:189.4536}).wait(1).to({graphics:mask_1_graphics_117,x:405.2914,y:188.4179}).wait(1).to({graphics:mask_1_graphics_118,x:405.2914,y:187.3821}).wait(1).to({graphics:mask_1_graphics_119,x:405.2914,y:186.3464}).wait(1).to({graphics:mask_1_graphics_120,x:405.2914,y:185.3107}).wait(1).to({graphics:mask_1_graphics_121,x:405.2914,y:184.275}).wait(1).to({graphics:mask_1_graphics_122,x:405.2914,y:183.2393}).wait(1).to({graphics:mask_1_graphics_123,x:405.2914,y:182.2036}).wait(1).to({graphics:mask_1_graphics_124,x:405.2914,y:181.1679}).wait(1).to({graphics:mask_1_graphics_125,x:405.2914,y:180.1321}).wait(1).to({graphics:mask_1_graphics_126,x:405.2914,y:179.0964}).wait(1).to({graphics:mask_1_graphics_127,x:405.2914,y:178.0607}).wait(1).to({graphics:mask_1_graphics_128,x:405.2914,y:177.025}).wait(15));

	// B_Social
	this.Soc = new lib.Social_media();
	this.Soc.name = "Soc";
	this.Soc.setTransform(712.75,334.15,1,1,0,0,0,93,21.4);
	this.Soc._off = true;
	new cjs.ButtonHelper(this.Soc, 0, 1, 2, false, new lib.Social_media(), 3);

	var maskedShapeInstanceList = [this.Soc];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.Soc).wait(114).to({_off:false},0).wait(29));

	// M_Ilust (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_100 = new cjs.Graphics().p("AexXIIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_101 = new cjs.Graphics().p("AexW+IAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_102 = new cjs.Graphics().p("AexW0IAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_103 = new cjs.Graphics().p("AexWpIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_104 = new cjs.Graphics().p("AexWfIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_105 = new cjs.Graphics().p("AexWUIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_106 = new cjs.Graphics().p("AexWKIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_107 = new cjs.Graphics().p("AexWAIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_108 = new cjs.Graphics().p("AexV1IAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_109 = new cjs.Graphics().p("AexVrIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_110 = new cjs.Graphics().p("AexVhIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_111 = new cjs.Graphics().p("AexVWIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_112 = new cjs.Graphics().p("AexVMIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_113 = new cjs.Graphics().p("AexVCIAAlSMAhGAAAIAAFSg");
	var mask_2_graphics_114 = new cjs.Graphics().p("AexU3IAAlSMAhGAAAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(100).to({graphics:mask_2_graphics_100,x:408.7347,y:148.025}).wait(1).to({graphics:mask_2_graphics_101,x:408.7347,y:146.9893}).wait(1).to({graphics:mask_2_graphics_102,x:408.7347,y:145.9536}).wait(1).to({graphics:mask_2_graphics_103,x:408.7347,y:144.9179}).wait(1).to({graphics:mask_2_graphics_104,x:408.7347,y:143.8821}).wait(1).to({graphics:mask_2_graphics_105,x:408.7347,y:142.8464}).wait(1).to({graphics:mask_2_graphics_106,x:408.7347,y:141.8107}).wait(1).to({graphics:mask_2_graphics_107,x:408.7347,y:140.775}).wait(1).to({graphics:mask_2_graphics_108,x:408.7347,y:139.7393}).wait(1).to({graphics:mask_2_graphics_109,x:408.7347,y:138.7036}).wait(1).to({graphics:mask_2_graphics_110,x:408.7347,y:137.6679}).wait(1).to({graphics:mask_2_graphics_111,x:408.7347,y:136.6321}).wait(1).to({graphics:mask_2_graphics_112,x:408.7347,y:135.5964}).wait(1).to({graphics:mask_2_graphics_113,x:408.7347,y:134.5607}).wait(1).to({graphics:mask_2_graphics_114,x:408.7347,y:133.525}).wait(29));

	// B_Ilust
	this.Ilust = new lib.Ilustraciones();
	this.Ilust.name = "Ilust";
	this.Ilust.setTransform(718.1,246.9,1,1,0,0,0,91.5,21.4);
	this.Ilust._off = true;
	new cjs.ButtonHelper(this.Ilust, 0, 1, 2, false, new lib.Ilustraciones(), 3);

	var maskedShapeInstanceList = [this.Ilust];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.Ilust).wait(100).to({_off:false},0).wait(43));

	// M_Contacto (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_86 = new cjs.Graphics().p("EAT0AhSIAAlSIXGAAIAAFSg");
	var mask_3_graphics_87 = new cjs.Graphics().p("EAT0AhIIAAlSIXGAAIAAFSg");
	var mask_3_graphics_88 = new cjs.Graphics().p("EAT0Ag+IAAlSIXGAAIAAFSg");
	var mask_3_graphics_89 = new cjs.Graphics().p("EAT0AgzIAAlSIXGAAIAAFSg");
	var mask_3_graphics_90 = new cjs.Graphics().p("EAT0AgpIAAlSIXGAAIAAFSg");
	var mask_3_graphics_91 = new cjs.Graphics().p("EAT0AgeIAAlSIXGAAIAAFSg");
	var mask_3_graphics_92 = new cjs.Graphics().p("EAT0AgUIAAlSIXGAAIAAFSg");
	var mask_3_graphics_93 = new cjs.Graphics().p("EAT0AgKIAAlSIXGAAIAAFSg");
	var mask_3_graphics_94 = new cjs.Graphics().p("AT0f/IAAlSIXGAAIAAFSg");
	var mask_3_graphics_95 = new cjs.Graphics().p("AT0f1IAAlSIXGAAIAAFSg");
	var mask_3_graphics_96 = new cjs.Graphics().p("AT0frIAAlSIXGAAIAAFSg");
	var mask_3_graphics_97 = new cjs.Graphics().p("AT0fgIAAlSIXGAAIAAFSg");
	var mask_3_graphics_98 = new cjs.Graphics().p("AT0fWIAAlSIXGAAIAAFSg");
	var mask_3_graphics_99 = new cjs.Graphics().p("AT0fMIAAlSIXGAAIAAFSg");
	var mask_3_graphics_100 = new cjs.Graphics().p("AT0fBIAAlSIXGAAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(86).to({graphics:mask_3_graphics_86,x:274.5959,y:213.025}).wait(1).to({graphics:mask_3_graphics_87,x:274.5959,y:211.9893}).wait(1).to({graphics:mask_3_graphics_88,x:274.5959,y:210.9536}).wait(1).to({graphics:mask_3_graphics_89,x:274.5959,y:209.9179}).wait(1).to({graphics:mask_3_graphics_90,x:274.5959,y:208.8821}).wait(1).to({graphics:mask_3_graphics_91,x:274.5959,y:207.8464}).wait(1).to({graphics:mask_3_graphics_92,x:274.5959,y:206.8107}).wait(1).to({graphics:mask_3_graphics_93,x:274.5959,y:205.775}).wait(1).to({graphics:mask_3_graphics_94,x:274.5959,y:204.7393}).wait(1).to({graphics:mask_3_graphics_95,x:274.5959,y:203.7036}).wait(1).to({graphics:mask_3_graphics_96,x:274.5959,y:202.6679}).wait(1).to({graphics:mask_3_graphics_97,x:274.5959,y:201.6321}).wait(1).to({graphics:mask_3_graphics_98,x:274.5959,y:200.5964}).wait(1).to({graphics:mask_3_graphics_99,x:274.5959,y:199.5607}).wait(1).to({graphics:mask_3_graphics_100,x:274.5959,y:198.525}).wait(43));

	// B_Contacto
	this.Cont = new lib.Contacto();
	this.Cont.name = "Cont";
	this.Cont.setTransform(479.95,376.9,1,1,0,0,0,65.2,21.4);
	this.Cont._off = true;
	new cjs.ButtonHelper(this.Cont, 0, 1, 2, false, new lib.Contacto(), 3);

	var maskedShapeInstanceList = [this.Cont];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.Cont).wait(86).to({_off:false},0).wait(57));

	// M_Intro (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_72 = new cjs.Graphics().p("AatafIAAlSINtAAIAAFSg");
	var mask_4_graphics_73 = new cjs.Graphics().p("AataUIAAlSINtAAIAAFSg");
	var mask_4_graphics_74 = new cjs.Graphics().p("AataKIAAlSINtAAIAAFSg");
	var mask_4_graphics_75 = new cjs.Graphics().p("AataAIAAlSINtAAIAAFSg");
	var mask_4_graphics_76 = new cjs.Graphics().p("AatZ2IAAlSINtAAIAAFSg");
	var mask_4_graphics_77 = new cjs.Graphics().p("AatZrIAAlSINtAAIAAFSg");
	var mask_4_graphics_78 = new cjs.Graphics().p("AatZhIAAlSINtAAIAAFSg");
	var mask_4_graphics_79 = new cjs.Graphics().p("AatZXIAAlSINtAAIAAFSg");
	var mask_4_graphics_80 = new cjs.Graphics().p("AatZMIAAlSINtAAIAAFSg");
	var mask_4_graphics_81 = new cjs.Graphics().p("AatZCIAAlSINtAAIAAFSg");
	var mask_4_graphics_82 = new cjs.Graphics().p("AatY4IAAlSINtAAIAAFSg");
	var mask_4_graphics_83 = new cjs.Graphics().p("AatYuIAAlSINtAAIAAFSg");
	var mask_4_graphics_84 = new cjs.Graphics().p("AatYjIAAlSINtAAIAAFSg");
	var mask_4_graphics_85 = new cjs.Graphics().p("AatYZIAAlSINtAAIAAFSg");
	var mask_4_graphics_86 = new cjs.Graphics().p("AatYPIAAlSINtAAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(72).to({graphics:mask_4_graphics_72,x:258.5564,y:169.475}).wait(1).to({graphics:mask_4_graphics_73,x:258.5564,y:168.4464}).wait(1).to({graphics:mask_4_graphics_74,x:258.5564,y:167.4179}).wait(1).to({graphics:mask_4_graphics_75,x:258.5564,y:166.3893}).wait(1).to({graphics:mask_4_graphics_76,x:258.5564,y:165.3607}).wait(1).to({graphics:mask_4_graphics_77,x:258.5564,y:164.3321}).wait(1).to({graphics:mask_4_graphics_78,x:258.5564,y:163.3036}).wait(1).to({graphics:mask_4_graphics_79,x:258.5564,y:162.275}).wait(1).to({graphics:mask_4_graphics_80,x:258.5564,y:161.2464}).wait(1).to({graphics:mask_4_graphics_81,x:258.5564,y:160.2179}).wait(1).to({graphics:mask_4_graphics_82,x:258.5564,y:159.1893}).wait(1).to({graphics:mask_4_graphics_83,x:258.5564,y:158.1607}).wait(1).to({graphics:mask_4_graphics_84,x:258.5564,y:157.1321}).wait(1).to({graphics:mask_4_graphics_85,x:258.5564,y:156.1036}).wait(1).to({graphics:mask_4_graphics_86,x:258.5564,y:155.075}).wait(57));

	// B_Intro
	this.Intro = new lib.Intro();
	this.Intro.name = "Intro";
	this.Intro.setTransform(480,289.8,1,1,0,0,0,36.1,21.4);
	this.Intro._off = true;
	new cjs.ButtonHelper(this.Intro, 0, 1, 2, false, new lib.Intro(), 3);

	var maskedShapeInstanceList = [this.Intro];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.Intro).wait(72).to({_off:false},0).wait(71));

	// M_Ident (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_58 = new cjs.Graphics().p("EgKVAktIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_59 = new cjs.Graphics().p("EgKVAkiIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_60 = new cjs.Graphics().p("EgKVAkYIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_61 = new cjs.Graphics().p("EgKVAkNIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_62 = new cjs.Graphics().p("EgKVAkCIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_63 = new cjs.Graphics().p("EgKVAj3IAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_64 = new cjs.Graphics().p("EgKVAjtIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_65 = new cjs.Graphics().p("EgKVAjiIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_66 = new cjs.Graphics().p("EgKVAjXIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_67 = new cjs.Graphics().p("EgKVAjNIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_68 = new cjs.Graphics().p("EgKVAjCIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_69 = new cjs.Graphics().p("EgKVAi3IAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_70 = new cjs.Graphics().p("EgKVAisIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_71 = new cjs.Graphics().p("EgKVAiiIAAlSMAoXAAAIAAFSg");
	var mask_5_graphics_72 = new cjs.Graphics().p("EgKVAiXIAAlSMAoXAAAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_5_graphics_58,x:192.1684,y:234.9}).wait(1).to({graphics:mask_5_graphics_59,x:192.1684,y:233.8286}).wait(1).to({graphics:mask_5_graphics_60,x:192.1684,y:232.7571}).wait(1).to({graphics:mask_5_graphics_61,x:192.1684,y:231.6857}).wait(1).to({graphics:mask_5_graphics_62,x:192.1684,y:230.6143}).wait(1).to({graphics:mask_5_graphics_63,x:192.1684,y:229.5429}).wait(1).to({graphics:mask_5_graphics_64,x:192.1684,y:228.4714}).wait(1).to({graphics:mask_5_graphics_65,x:192.1684,y:227.4}).wait(1).to({graphics:mask_5_graphics_66,x:192.1684,y:226.3286}).wait(1).to({graphics:mask_5_graphics_67,x:192.1684,y:225.2571}).wait(1).to({graphics:mask_5_graphics_68,x:192.1684,y:224.1857}).wait(1).to({graphics:mask_5_graphics_69,x:192.1684,y:223.1143}).wait(1).to({graphics:mask_5_graphics_70,x:192.1684,y:222.0429}).wait(1).to({graphics:mask_5_graphics_71,x:192.1684,y:220.9714}).wait(1).to({graphics:mask_5_graphics_72,x:192.1684,y:219.9}).wait(71));

	// B_Ident
	this.Ident = new lib.Identidad_visual();
	this.Ident.name = "Ident";
	this.Ident.setTransform(267.1,419.65,1,1,0,0,0,116.8,21.4);
	this.Ident._off = true;
	new cjs.ButtonHelper(this.Ident, 0, 1, 2, false, new lib.Identidad_visual(), 3);

	var maskedShapeInstanceList = [this.Ident];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.Ident).wait(58).to({_off:false},0).wait(85));

	// M_Educ (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_44 = new cjs.Graphics().p("AkYeAIAAlSIcJAAIAAFSg");
	var mask_6_graphics_45 = new cjs.Graphics().p("AkYd0IAAlSIcJAAIAAFSg");
	var mask_6_graphics_46 = new cjs.Graphics().p("AkYdoIAAlSIcJAAIAAFSg");
	var mask_6_graphics_47 = new cjs.Graphics().p("AkYdcIAAlSIcJAAIAAFSg");
	var mask_6_graphics_48 = new cjs.Graphics().p("AkYdQIAAlSIcJAAIAAFSg");
	var mask_6_graphics_49 = new cjs.Graphics().p("AkYdEIAAlSIcJAAIAAFSg");
	var mask_6_graphics_50 = new cjs.Graphics().p("AkYc3IAAlSIcJAAIAAFSg");
	var mask_6_graphics_51 = new cjs.Graphics().p("AkYcrIAAlSIcJAAIAAFSg");
	var mask_6_graphics_52 = new cjs.Graphics().p("AkYcfIAAlSIcJAAIAAFSg");
	var mask_6_graphics_53 = new cjs.Graphics().p("AkYcTIAAlSIcJAAIAAFSg");
	var mask_6_graphics_54 = new cjs.Graphics().p("AkYcHIAAlSIcJAAIAAFSg");
	var mask_6_graphics_55 = new cjs.Graphics().p("AkYb7IAAlSIcJAAIAAFSg");
	var mask_6_graphics_56 = new cjs.Graphics().p("AkYbvIAAlSIcJAAIAAFSg");
	var mask_6_graphics_57 = new cjs.Graphics().p("AkYbiIAAlSIcJAAIAAFSg");
	var mask_6_graphics_58 = new cjs.Graphics().p("AkYbWIAAlSIcJAAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_6_graphics_44,x:152.0849,y:192.025}).wait(1).to({graphics:mask_6_graphics_45,x:152.0849,y:190.8107}).wait(1).to({graphics:mask_6_graphics_46,x:152.0849,y:189.5964}).wait(1).to({graphics:mask_6_graphics_47,x:152.0849,y:188.3821}).wait(1).to({graphics:mask_6_graphics_48,x:152.0849,y:187.1679}).wait(1).to({graphics:mask_6_graphics_49,x:152.0849,y:185.9536}).wait(1).to({graphics:mask_6_graphics_50,x:152.0849,y:184.7393}).wait(1).to({graphics:mask_6_graphics_51,x:152.0849,y:183.525}).wait(1).to({graphics:mask_6_graphics_52,x:152.0849,y:182.3107}).wait(1).to({graphics:mask_6_graphics_53,x:152.0849,y:181.0964}).wait(1).to({graphics:mask_6_graphics_54,x:152.0849,y:179.8821}).wait(1).to({graphics:mask_6_graphics_55,x:152.0849,y:178.6679}).wait(1).to({graphics:mask_6_graphics_56,x:152.0849,y:177.4536}).wait(1).to({graphics:mask_6_graphics_57,x:152.0849,y:176.2393}).wait(1).to({graphics:mask_6_graphics_58,x:152.0849,y:175.025}).wait(85));

	// B_Educ
	this.Educ = new lib.Educacion();
	this.Educ.name = "Educ";
	this.Educ.setTransform(226.3,334.15,1,1,0,0,0,76,21.4);
	this.Educ._off = true;
	new cjs.ButtonHelper(this.Educ, 0, 1, 2, false, new lib.Educacion(), 3);

	var maskedShapeInstanceList = [this.Educ];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.Educ).wait(44).to({_off:false},0).wait(99));

	// M_Perfil (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	var mask_7_graphics_30 = new cjs.Graphics().p("AB7XSIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_31 = new cjs.Graphics().p("AB7XGIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_32 = new cjs.Graphics().p("AB7W6IAAlSIQ1AAIAAFSg");
	var mask_7_graphics_33 = new cjs.Graphics().p("AB7WuIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_34 = new cjs.Graphics().p("AB7WiIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_35 = new cjs.Graphics().p("AB7WWIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_36 = new cjs.Graphics().p("AB7WJIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_37 = new cjs.Graphics().p("AB7V9IAAlSIQ1AAIAAFSg");
	var mask_7_graphics_38 = new cjs.Graphics().p("AB7VxIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_39 = new cjs.Graphics().p("AB7VlIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_40 = new cjs.Graphics().p("AB7VZIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_41 = new cjs.Graphics().p("AB7VNIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_42 = new cjs.Graphics().p("AB7VBIAAlSIQ1AAIAAFSg");
	var mask_7_graphics_43 = new cjs.Graphics().p("AB7U0IAAlSIQ1AAIAAFSg");
	var mask_7_graphics_44 = new cjs.Graphics().p("AB7UoIAAlSIQ1AAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_7).to({graphics:null,x:0,y:0}).wait(30).to({graphics:mask_7_graphics_30,x:120.025,y:149.025}).wait(1).to({graphics:mask_7_graphics_31,x:120.025,y:147.8107}).wait(1).to({graphics:mask_7_graphics_32,x:120.025,y:146.5964}).wait(1).to({graphics:mask_7_graphics_33,x:120.025,y:145.3821}).wait(1).to({graphics:mask_7_graphics_34,x:120.025,y:144.1679}).wait(1).to({graphics:mask_7_graphics_35,x:120.025,y:142.9536}).wait(1).to({graphics:mask_7_graphics_36,x:120.025,y:141.7393}).wait(1).to({graphics:mask_7_graphics_37,x:120.025,y:140.525}).wait(1).to({graphics:mask_7_graphics_38,x:120.025,y:139.3107}).wait(1).to({graphics:mask_7_graphics_39,x:120.025,y:138.0964}).wait(1).to({graphics:mask_7_graphics_40,x:120.025,y:136.8821}).wait(1).to({graphics:mask_7_graphics_41,x:120.025,y:135.6679}).wait(1).to({graphics:mask_7_graphics_42,x:120.025,y:134.4536}).wait(1).to({graphics:mask_7_graphics_43,x:120.025,y:133.2393}).wait(1).to({graphics:mask_7_graphics_44,x:120.025,y:132.025}).wait(99));

	// B_Perfil
	this.Perfil = new lib.Perfil();
	this.Perfil.name = "Perfil";
	this.Perfil.setTransform(191.3,246.9,1,1,0,0,0,41,21.4);
	this.Perfil._off = true;
	new cjs.ButtonHelper(this.Perfil, 0, 1, 2, false, new lib.Perfil(), 3);

	var maskedShapeInstanceList = [this.Perfil];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get(this.Perfil).wait(30).to({_off:false},0).wait(113));

	// Linea
	this.instance = new lib.Linea("synched",0);
	this.instance.setTransform(480.05,188.85,0.0448,1,0,0,0,106.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:106.1,regY:1.5,scaleX:1,x:480,y:188.75},16).wait(127));

	// M_Cont (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	var mask_8_graphics_16 = new cjs.Graphics().p("AMoO3IAAgeMAhLAAAIAAAeg");
	var mask_8_graphics_17 = new cjs.Graphics().p("AMoO3IAAg/MAhLAAAIAAA/g");
	var mask_8_graphics_18 = new cjs.Graphics().p("AMoO3IAAhhMAhLAAAIAABhg");
	var mask_8_graphics_19 = new cjs.Graphics().p("AMoO3IAAiCMAhLAAAIAACCg");
	var mask_8_graphics_20 = new cjs.Graphics().p("AMoO3IAAikMAhLAAAIAACkg");
	var mask_8_graphics_21 = new cjs.Graphics().p("AMoO3IAAjGMAhLAAAIAADGg");
	var mask_8_graphics_22 = new cjs.Graphics().p("AMoO3IAAjnMAhLAAAIAADng");
	var mask_8_graphics_23 = new cjs.Graphics().p("AMoO3IAAkJMAhLAAAIAAEJg");
	var mask_8_graphics_24 = new cjs.Graphics().p("AMoO3IAAkqMAhLAAAIAAEqg");
	var mask_8_graphics_25 = new cjs.Graphics().p("AMoO3IAAlMMAhLAAAIAAFMg");
	var mask_8_graphics_26 = new cjs.Graphics().p("AMoO3IAAltMAhLAAAIAAFtg");
	var mask_8_graphics_27 = new cjs.Graphics().p("AMoO3IAAmPMAhLAAAIAAGPg");
	var mask_8_graphics_28 = new cjs.Graphics().p("AMoO3IAAmxMAhLAAAIAAGxg");
	var mask_8_graphics_29 = new cjs.Graphics().p("AMoO3IAAnSMAhLAAAIAAHSg");
	var mask_8_graphics_30 = new cjs.Graphics().p("AMoO3IAAn0MAhLAAAIAAH0g");

	this.timeline.addTween(cjs.Tween.get(mask_8).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_8_graphics_16,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_17,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_18,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_19,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_20,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_21,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_22,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_23,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_24,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_25,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_26,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_27,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_28,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_29,x:293.0753,y:95.125}).wait(1).to({graphics:mask_8_graphics_30,x:293.0753,y:95.125}).wait(113));

	// T_Cont
	this.instance_1 = new lib.GContenido("synched",0);
	this.instance_1.setTransform(480,163.75);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_8;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({_off:false},0).wait(127));

	// B_Atras
	this.Atras = new lib.Atras();
	this.Atras.name = "Atras";
	this.Atras.setTransform(100.65,542.95);
	new cjs.ButtonHelper(this.Atras, 0, 1, 2, false, new lib.Atras(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Atras).wait(143));

	// B_Sig
	this.Siguiente = new lib.Siguiente();
	this.Siguiente.name = "Siguiente";
	this.Siguiente.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.Siguiente, 0, 1, 2, false, new lib.Siguiente(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Siguiente).wait(143));

	// Diseño
	this.instance_2 = new lib.Pantalla("synched",0);
	this.instance_2.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_3 = new lib.Pantalla("synched",0);
	this.instance_3.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#121212").s().p("EhK/AyFMAAAhkJMCV/AAAMAAABkJg");
	this.shape.setTransform(480.025,320.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_3},{t:this.instance_2}]}).wait(143));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(480.1,320.1,479.9,320.9);
// library properties:
lib.properties = {
	id: '5163ED934AAE5C43889CE47714127A5F',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/contenido_atlas_1.png?1655438717955", id:"contenido_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5163ED934AAE5C43889CE47714127A5F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;