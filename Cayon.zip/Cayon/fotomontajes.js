(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fotomontajes_atlas_1", frames: [[555,1084,171,76],[1054,1084,74,76],[728,1084,104,76],[932,1084,120,57],[932,1143,68,76],[834,1084,96,76],[0,0,1719,1082],[0,1205,98,51],[0,1084,553,119]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_476 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_475 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_474 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_473 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_472 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_471 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_470 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_469 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_468 = function() {
	this.initialize(ss["fotomontajes_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Vertical = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EgWpgqKMAtTAAAMAAABUVMgtTAAAg");
	this.shape.setTransform(43.86,81.6491,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,89.8,165.3);


(lib.Linea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#898989").s().p("AvmAPIAAgdIfNAAIAAAdg");
	this.shape.setTransform(106.1313,1.5,1.0623,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,212.3,3);


(lib.Horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(0.1,1,1).p("EhDLgODMCGXAAAIAAcHMiGXAAAg");
	this.shape.setTransform(130.0675,27.2142,0.3025,0.3025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,262.2,56.5);


(lib.Carga4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape.setTransform(0.5,2.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1,4.1);


(lib.Carga3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgZAjIAAhFIAzAAIggBFg");
	this.shape.setTransform(2.6,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,5.2,6.9);


(lib.Carga2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgoAjIAihFIAvAAIgiBFg");
	this.shape.setTransform(4.075,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,8.2,6.9);


(lib.Carga1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgdAjIAhhFIAaAAIAABFg");
	this.shape.setTransform(2.975,3.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6,6.9);


(lib.Boton_Sig = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiPhsIEfBvIkfBqg");
	this.shape.setTransform(14.375,10.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiPhsIEfBvIkfBqg");
	this.shape_1.setTransform(14.375,10.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.9);


(lib.Boton_Contenido = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape.setTransform(14.475,10.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiQBuIAAjbIEhAAIAADbg");
	this.shape_1.setTransform(14.475,10.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,29,22);


(lib.Boton_Atras = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#393939").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape.setTransform(14.4,10.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AiCgBIgNgFIANgFIEShhIgDDZg");
	this.shape_1.setTransform(14.4,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,21.8);


(lib.Bateria = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_4
	this.instance = new lib.Carga1("synched",0);
	this.instance.setTransform(11.3,3.65,1,1,0,0,0,3,3.5);

	this.instance_1 = new lib.Carga2("synched",0);
	this.instance_1.setTransform(7.35,3.65,1,1,0,0,0,4,3.5);

	this.instance_2 = new lib.Carga3("synched",0);
	this.instance_2.setTransform(3.9,3.6,1,1,0,0,0,2.6,3.5);

	this.instance_3 = new lib.Carga4("synched",0);
	this.instance_3.setTransform(0.6,3.35,1,1,0,0,0,0.5,2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance},{t:this.instance_1}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},10).to({state:[{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},10).wait(11));

	// Capa_1
	this.instance_4 = new lib.CachedBmp_469();
	this.instance_4.setTransform(-0.35,-0.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.3,14.9,7.7);


(lib.Pantalla = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Bateria();
	this.instance.setTransform(254.2,26.5,1,1,0,0,0,7,3.5);

	this.instance_1 = new lib.Horizontal("synched",0);
	this.instance_1.setTransform(144.95,96.5,1,1,0,0,0,130.1,27.2);
	this.instance_1.alpha = 0.0703;

	this.instance_2 = new lib.Vertical("synched",0);
	this.instance_2.setTransform(144.95,96.55,1,1,0,0,0,43.9,81.7);
	this.instance_2.alpha = 0.0703;

	this.instance_3 = new lib.CachedBmp_476();
	this.instance_3.setTransform(198.85,162.7,0.1519,0.1519);

	this.instance_4 = new lib.CachedBmp_475();
	this.instance_4.setTransform(166.75,162.5,0.1519,0.1519);

	this.instance_5 = new lib.CachedBmp_474();
	this.instance_5.setTransform(147.1,162.5,0.1519,0.1519);

	this.instance_6 = new lib.CachedBmp_473();
	this.instance_6.setTransform(146.6,164.25,0.1519,0.1519);

	this.instance_7 = new lib.CachedBmp_472();
	this.instance_7.setTransform(111.25,162.5,0.1519,0.1519);

	this.instance_8 = new lib.CachedBmp_471();
	this.instance_8.setTransform(76.55,162.5,0.1519,0.1519);

	this.instance_9 = new lib.CachedBmp_470();
	this.instance_9.setTransform(14.35,14.35,0.1519,0.1519);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.9,13.9,262.1,165.29999999999998);


// stage content:
(lib.fotomontajes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,30];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Atras.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('trepadora.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Cont.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('contenido.html', '_self');
		});
		var _this = this;
		/*
		Al hacer clic en la instancia del símbolo especificada, se ejecuta una función.
		*/
		_this.Sig.on('click', function(){
		/*
		Carga la URL en una ventana nueva del navegador.
		*/
		window.open('Montaje_Pez.html', '_self');
		});
	}
	this.frame_30 = function() {
		var _this = this;
		/*
		Detener un clip de película o un vídeo
		Detiene el clip de película o el vídeo especificado.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30).call(this.frame_30).wait(1));

	// M_Fotom (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_16 = new cjs.Graphics().p("AMUa+IAAgeMAzTAAAIAAAeg");
	var mask_graphics_17 = new cjs.Graphics().p("AMVa+IAAg/MAzQAAAIAAA/g");
	var mask_graphics_18 = new cjs.Graphics().p("AMVa+IAAhhMAzPAAAIAABhg");
	var mask_graphics_19 = new cjs.Graphics().p("AMVa+IAAiCMAzOAAAIAACCg");
	var mask_graphics_20 = new cjs.Graphics().p("AMVa+IAAikMAzMAAAIAACkg");
	var mask_graphics_21 = new cjs.Graphics().p("AMVa+IAAjGMAzLAAAIAADGg");
	var mask_graphics_22 = new cjs.Graphics().p("AMWa+IAAjnMAzIAAAIAADng");
	var mask_graphics_23 = new cjs.Graphics().p("AMWa+IAAkJMAzHAAAIAAEJg");
	var mask_graphics_24 = new cjs.Graphics().p("AMWa+IAAkqMAzFAAAIAAEqg");
	var mask_graphics_25 = new cjs.Graphics().p("AMWa+IAAlMMAzEAAAIAAFMg");
	var mask_graphics_26 = new cjs.Graphics().p("AMWa+IAAltMAzCAAAIAAFtg");
	var mask_graphics_27 = new cjs.Graphics().p("AMXa+IAAmPMAzAAAAIAAGPg");
	var mask_graphics_28 = new cjs.Graphics().p("AMXa+IAAmxMAy/AAAIAAGxg");
	var mask_graphics_29 = new cjs.Graphics().p("AMXa+IAAnSMAy9AAAIAAHSg");
	var mask_graphics_30 = new cjs.Graphics().p("AMXa+IAAn0MAy7AAAIAAH0g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_graphics_16,x:407.0899,y:172.625}).wait(1).to({graphics:mask_graphics_17,x:406.945,y:172.625}).wait(1).to({graphics:mask_graphics_18,x:406.8,y:172.625}).wait(1).to({graphics:mask_graphics_19,x:406.6551,y:172.625}).wait(1).to({graphics:mask_graphics_20,x:406.5102,y:172.625}).wait(1).to({graphics:mask_graphics_21,x:406.3652,y:172.625}).wait(1).to({graphics:mask_graphics_22,x:406.2203,y:172.625}).wait(1).to({graphics:mask_graphics_23,x:406.0753,y:172.625}).wait(1).to({graphics:mask_graphics_24,x:405.9304,y:172.625}).wait(1).to({graphics:mask_graphics_25,x:405.7855,y:172.625}).wait(1).to({graphics:mask_graphics_26,x:405.6405,y:172.625}).wait(1).to({graphics:mask_graphics_27,x:405.4956,y:172.625}).wait(1).to({graphics:mask_graphics_28,x:405.3506,y:172.625}).wait(1).to({graphics:mask_graphics_29,x:405.2057,y:172.625}).wait(1).to({graphics:mask_graphics_30,x:405.0224,y:172.625}).wait(1));

	// Fotom
	this.instance = new lib.CachedBmp_468();
	this.instance.setTransform(533.45,289.85,0.5,0.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).wait(15));

	// Linea
	this.instance_1 = new lib.Linea("synched",0);
	this.instance_1.setTransform(644.05,344.85,0.0448,1,0,0,0,106.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:106.4,regY:1.5,scaleX:1.3053,x:671.35,y:344.75},16).wait(15));

	// Boton_Atras
	this.Atras = new lib.Boton_Atras();
	this.Atras.name = "Atras";
	this.Atras.setTransform(100.65,542.95);
	new cjs.ButtonHelper(this.Atras, 0, 1, 2, false, new lib.Boton_Atras(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Atras).wait(31));

	// Boton_Cont
	this.Cont = new lib.Boton_Contenido();
	this.Cont.name = "Cont";
	this.Cont.setTransform(152.55,553.8,1,1,0,0,0,14.5,11);
	new cjs.ButtonHelper(this.Cont, 0, 1, 2, false, new lib.Boton_Contenido(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Cont).wait(31));

	// Boton_Sig
	this.Sig = new lib.Boton_Sig();
	this.Sig.name = "Sig";
	this.Sig.setTransform(189.7,553.7,1,1,0,0,0,14.3,10.9);
	new cjs.ButtonHelper(this.Sig, 0, 1, 2, false, new lib.Boton_Sig(), 3);

	this.timeline.addTween(cjs.Tween.get(this.Sig).wait(31));

	// Diseño
	this.instance_2 = new lib.Pantalla("synched",0);
	this.instance_2.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_3 = new lib.Pantalla("synched",0);
	this.instance_3.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_4 = new lib.Pantalla("synched",0);
	this.instance_4.setTransform(481.2,319.3,3.2917,3.2917,0,0,0,145.1,96.6);

	this.instance_5 = new lib.Pantalla("synched",0);
	this.instance_5.setTransform(480.7,319.35,3.2917,3.2917,0,0,0,145.1,96.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#121212").s().p("EhLBAyIMAAAhkPMCWEAAAMAAABkPg");
	this.shape.setTransform(480.5,320.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(31));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(480.3,320,480.49999999999994,321.6);
// library properties:
lib.properties = {
	id: 'A7B9E1DE34AE9C468571C1F532CD0EF5',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fotomontajes_atlas_1.png?1655440210502", id:"fotomontajes_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A7B9E1DE34AE9C468571C1F532CD0EF5'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;